<?php
session_start(); // Start or resume a session

$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "DBClinicmain";

// Create a connection to the database
$conn = mysqli_connect($host, $dbUsername, $dbPassword, $dbname);

// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_SESSION['userID'], $_SESSION['userName'])) {
    // Both $_SESSION['userID'] and $_SESSION['userName'] are set
    $userID = $_SESSION['userID'];
    $userName = $_SESSION['userName'];

    // Check if the patient has active appointments or pending payments
    $sqlAppointments = "SELECT * FROM Tbl_Appointment WHERE Patient_ID = '$userID' AND Status = 'Active'";
    $sqlPayments = "SELECT * FROM Tbl_Payment WHERE Patient_ID = '$userID' AND Status = 'Pending'";

    $resultAppointments = mysqli_query($conn, $sqlAppointments);
    $resultPayments = mysqli_query($conn, $sqlPayments);

    if (mysqli_num_rows($resultAppointments) > 0 || mysqli_num_rows($resultPayments) > 0) {
        // The patient has active appointments or pending payments, so they cannot delete the account
        echo "You cannot delete your account due to active appointments or pending payments.";
    } else {
        // No active appointments or pending payments, allow the patient to delete the account

        if (isset($_POST['confirmDelete'])) {
            // Delete the patient's record from the tbl_Patient table
            $sqlDeletePatient = "DELETE FROM tbl_Patient WHERE Patient_ID = '$userID'";
            if (mysqli_query($conn, $sqlDeletePatient)) {
                // Account successfully deleted, you can redirect or display a message
                echo "Your account has been deleted.";
                // You can provide a link to the main page or any other relevant action here.
            } else {
                echo "Error deleting the account: " . mysqli_error($conn);
            }
        } else {
            // Display a confirmation button
            echo "Do you really want to delete your account? This action cannot be undone.<br>";
            echo "<form method='post'>";
            echo "<input type='submit' name='confirmDelete' value='Confirm Deletion'>";
            echo "</form>";
        }
    }
} else {
    // Redirect to the login page if the user is not authenticated
    header("Location: Login.php");
    exit;
}

// Close the database connection
mysqli_close($conn);
?>
