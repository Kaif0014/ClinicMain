<?php
session_start();

$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "dbclinicmain";

$conn = mysqli_connect($host, $dbUsername, $dbPassword, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$recepID = "";
$recepName = "";
$recepEmail = "";

if (isset($_SESSION['receptionist_email'])) {
    $recepEmail = $_SESSION['receptionist_email'];

    $sql = "SELECT * FROM tbl_receptionist WHERE Email = '$recepEmail'";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        if (mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            $recepID = htmlspecialchars($row["Receptionist_ID"]);
            $recepName = htmlspecialchars($row["Receptionist_Name"]);
        } else {
            echo "<p>No receptionist found with the provided email.</p>";
        }
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}

$sql = "SELECT
            A.Appointment_ID,
            A.Date,
            A.Patient_ID,
            A.Treatment_ID,
            A.Date,
            T.Treatment_Name,
            T.Treatment_Desc,
            T.Cost,
            T.Dentist_ID,
            P.Status AS Payment_Status,
            PA.Patient_Name,
            D.Dentist_Name
        FROM
            Tbl_Payment P
        INNER JOIN
            Tbl_Appointment A ON P.Appointment_ID = A.Appointment_ID
        INNER JOIN
            Tbl_Treatment T ON A.Treatment_ID = T.Treatment_ID
        INNER JOIN
            Tbl_Patient PA ON A.Patient_ID = PA.Patient_ID
        INNER JOIN
            Tbl_Dentist D ON T.Dentist_ID = D.Dentist_ID
        WHERE
            P.Status = 'Paid'";
$resultt = mysqli_query($conn, $sql);

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Payments</title>
    <style>
        body, h1, h2, p, ul, li {
            margin: 0;
            padding: 0;
        }

        .navbar {
            background-color: #ffc107;
            color: #fff;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
        }

        .navbar-brand {
            font-size: 24px;
            color: #fff;
        }

        .navbar-right {
            display: flex;
            align-items: center;
        }

        .recep-welcome {
            color: #fff;
            margin-right: 10px;
        }

        .welcome-icon {
            color: #fff;
            font-size: 24px;
        }

        .sidebar {
            height: 100%;
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #333;
            padding-top: 20px;
            transition: width 0.3s;
        }

        .sidebar h2 {
            color: white;
            text-align: center;
        }

        .sidebar ul {
            list-style-type: none;
            padding: 0;
        }

        .sidebar li {
            margin-bottom: 10px;
            text-align: center;
        }

        .sidebar a {
            display: block;
            text-decoration: none;
            color: white;
            padding: 10px;
            transition: background-color 0.3s;
        }

        .sidebar a:hover {
            background-color: #555;
        }

        .content {
            margin-left: 250px;
            padding: 20px;
        }

        .content h1 {
            font-size: 36px;
            margin-bottom: 20px;
        }

        .card {
            background-color: #fff;
            border: 1px solid #ccc;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .card h2 {
            font-size: 20px;
            margin-bottom: 10px;
            color: #333;
        }

        .card p {
            font-size: 16px;
            margin-bottom: 10px;
            color: #555;
        }

        .payment-button {
            background-color: #4CAF50;
            color: white;
            padding: 5px 10px;
            border: none;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="navbar-left">
            <a class="navbar-brand" href="#">Bracewell Clinic</a>
        </div>
        <div class="navbar-right">
            <span class="recep-welcome">Welcome, <?php echo $recepName; ?></span>
            <i class="welcome-icon fas fa-user"></i>
        </div>
    </nav>

 <div class="sidebar">
        <h2>Dashboard</h2>
        <ul>
            <li><a href="#">Home</a></li>
            <li><a href="receptionist_process.php">Appointments</a></li>
            <li><a href="Dentist_Availability.php">Dentist Availability</a></li>
            <li><a href="Recep_Manager.php">Patients</a></li>
            <li><a href="Receptionist_Settings.php">Settings</a></li>
            <li><a href="Manage_Payments.php">Manage Payments</a></li>
            <li><a href="Completed.php">Completed Appointments</a></li>
            <li><a href="Main.php">Logout</a></li>
        </ul>
    </div>
    <div class="content">
        <h1>Manage Payments</h1>
        <?php
        while ($row = mysqli_fetch_assoc($resultt)) {
            $appointmentID = $row["Appointment_ID"];
            echo "<div class='card'>";
            echo "<h2>Appointment ID: $appointmentID</h2>";
            echo "<p>Patient Name: " . $row["Patient_Name"] . "</p>";
            echo "<p>Treatment Name: " . $row["Treatment_Name"] . "</p>";
            echo "<p>Treatment Description: " . $row["Treatment_Desc"] . "</p>";
            echo "<p>Treatment Cost: " . $row["Cost"] . "</p>";
            echo "<p>Dentist Name: " . $row["Dentist_Name"] . "</p>";
            echo "<p>Appointment Date: " . $row["Date"] . "</p>";
            echo "<p>Payment Status: " . $row["Payment_Status"] . "</p>";
            echo "</div>";
        }
        ?>
    </div>
</body>
</html>
    