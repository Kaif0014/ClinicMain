<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Our Dentists</title>
    <!-- Link to Bootstrap 4 CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        /* Custom Styles */
        body {
            background-color: #f5f5f5;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .navbar {
            background-color: #99ccff;
        }

        .navbar-brand {
            font-size: 24px;
            color: #fff;
        }

        .navbar .btn-back {
            background-color: #333;
            border: none;
            color: #fff;
            font-size: 20px;
            border-radius: 5px;
        }

        .container {
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            padding: 20px;
            margin: 20px auto; /* Center the container horizontally */
            max-width: 800px; /* Limit the container width for better readability */
        }

        .doctor {
            text-align: center;
            margin-bottom: 30px;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            transition: transform 0.3s ease-in-out;
            overflow: hidden; /* Hide overflowing content */
            height: 360px; /* Set a fixed height for the cards */
        }

        .doctor:hover {
            transform: scale(1.05);
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
        }

        .doctor img {
            max-width: 150px;
            max-height: 150px;
            border-radius: 50%;
        }

        .doctor h3 {
            font-size: 24px;
            color: #333;
            margin: 10px 0;
        }

        .doctor p {
            font-size: 16px;
            color: #666;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar">
        <div class="container">
            <button class="navbar-brand btn-back"><a href="Main.php">Back</a></button>
        </div>
    </nav>

    <!-- Page Content -->
        <div class="container">
        <div class="row">
            <?php
            // Database configuration
            $host = "localhost";
            $dbUsername = "root";
            $dbPassword = "";
            $dbname = "DBClinicmain";

            // Create a connection
            $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);

            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Query to fetch dentist data
            $sql = "SELECT Dentist_Name, Gender, Address, Email, Experience FROM tbl_dentist";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                // Loop through the results and display each dentist's data
                while ($row = $result->fetch_assoc()) {
                    echo '<div class="col-md-4">';
                    echo '<div class="doctor">';
                         // You can add an image source here
                    echo '<h3>' . $row['Dentist_Name'] . '</h3>';
                    echo '<p>Specialty: ' . $row['Gender'] . '</p>';
                    echo '<p>Address: ' . $row['Address'] . '</p>';
                    echo '<p>Email: ' . $row['Email'] . '</p>';
                    echo '<p>Work Experience:' . $row['Experience'] . ' Years'.'</p>';
                    
                    // Generate random dummy data
                    echo '<p> ' . generateRandomData() . '</p>';
                    
                    echo '</div>';
                    echo '</div>';
                }
            }

            // Close the database connection
            $conn->close();

            // Function to generate random dummy data
            function generateRandomData() {
                $data = array(
                    "Graduated from a prestigious dental school.",
                    "Specializes in cosmetic dentistry.",
                    "Has 15 years of experience in oral surgery.",
                    "Received numerous awards for patient care.",
                    "Published articles in dental journals.",
                    "Participates in dental outreach programs.",
                    "Speaks multiple languages for international patients.",
                );
                return $data[array_rand($data)];
            }
            ?>
        </div>
    </div>
</body>
</html>
