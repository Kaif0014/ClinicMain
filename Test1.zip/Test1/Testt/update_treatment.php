<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Treatment</title>
    <style>
        /* Add your CSS styles for the page here */
        body {
            font-family: Arial, sans-serif;
        }

        h1 {
            color: #007BFF;
            text-align: center;
            margin-top: 20px;
        }

        .container {
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
        }

        form {
            text-align: center;
        }

        .form-group {
            margin-bottom: 20px;
        }

        input, select {
            width: 35.5%;
            padding: 10px;
            border: 2px solid #007BFF;
            border-radius: 5px;
            font-size: 16px;
            outline: none;
        }

        .btn {
            background-color: #007BFF;
            color: white;
            border: none;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 0 20px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <br>
    
    <a class="home-btn" href="admin.php">Back to Admin</a>
    <h1>Update Treatment</h1>
    <div class="container">
        <?php
        // Check if a treatment ID is provided in the URL
        if (isset($_GET['id'])) {
            $treatmentId = $_GET['id'];

            // Database connection
            $host = "localhost";
            $dbUsername = "root";
            $dbPassword = "";
            $dbname = "dbclinicmain";
            $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);

            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Fetch the treatment record by ID
            $sql = "SELECT * FROM tbl_treatment WHERE Treatment_ID = $treatmentId";
            $result = $conn->query($sql);

            if ($result !== false && $result->num_rows > 0) {
                $row = $result->fetch_assoc();
        ?>
            <form action="process_update_treatment.php" method="post">
                <div class="form-group">
                    <input type="hidden" name="id" value="<?php echo $row['Treatment_ID']; ?>">
                </div>
                <div class="form-group">
                    <input type="text" name="treatment_name" value="<?php echo $row['Treatment_Name']; ?>" required>
                </div>
                <div class="form-group">
                    <input type="text" name="treatment_desc" value="<?php echo $row['Treatment_Desc']; ?>" required>
                </div>
                <div class="form-group">
                    <input type="number" name="cost" value="<?php echo $row['Cost']; ?>" required>
                </div>
                <button type="submit" class="btn" name="submit">Update Treatment</button>
            </form>
        <?php
            } else {
                echo "Treatment not found.";
            }

            // Close the database connection
            $conn->close();
        } else {
            echo "Invalid treatment ID.";
        }
        ?>
    </div>
</body>
</html>
