<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $userOTP = '';
    for ($i = 1; $i <= 6; $i++) {
        $userOTP .= $_POST["digit$i"];
    }
    $storedOTP = $_SESSION['otp'];

    if ($userOTP == $storedOTP) {
        header("Location: new_password.php");
    } else {
        echo 'WRONG OTP';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Registration</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        /* Custom Styles */
        body {
            background-color: #f5f5f5;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .navbar {
            background-color: #007BFF;
            color: #fff;
        }

        .navbar-brand {
            font-size: 24px;
            color: #fff;
        }

        .container {
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            padding: 20px;
            margin: 20px auto;
            max-width: 400px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            font-weight: bold;
        }

        .form-control {
            border: 2px solid #007BFF;
            border-radius: 5px;
        }

        .otp-input {
            display: flex;
            justify-content: space-between;
        }

        .otp-digit {
            width: 40px;
            height: 40px;
            text-align: center;
            border: 2px solid #007BFF;
            border-radius: 5px;
            font-size: 18px;
        }

        .btn {
            background-color: #007BFF;
            color: #fff;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            cursor: pointer;
        }

        .btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
<nav class="navbar">
    <div class="container-fluid">
        <a class="navbar-brand" href="Main.php">Bracewell Clinic</a>
    </div>
</nav>

<div class="container">
    <h2 class="mt-4">OTP Verification</h2>
    <form action="forgot_verify.php" method="post">
        <div class="form-group">
            <label for="otp">Enter OTP:</label>
            <div class="otp-input">
                <?php
                for ($i = 1; $i <= 6; $i++) {
                    echo '<input type="text" class="form-control otp-digit" name="digit' . $i . '" maxlength="1" required>';
                }
                ?>
            </div>
        </div>
        <button type="submit" class="btn">Verify OTP</button>
    </form>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
