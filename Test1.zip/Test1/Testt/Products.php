<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products - Bracewell Clinic</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <!-- Add your custom stylesheets or styling here if needed -->
    <style>
        /* Add your additional styles here */
        body {
            background-color: #f8f8f8;
        }

        .container {
            margin-top: 20px;
        }

        .product {
            background-color: #fff;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 5px;
            text-align: center;
        }

        h3 {
            color: #333;
        }

        p {
            color: #666;
        }

        .buy-now-btn {
            margin-top: 10px;
        }
    </style>
</head>
<body>
   <nav class="navbar navbar-inverse">
        <div class="container-fluid">
            <!-- Back button -->
            <div class="navbar-header">
    <a class="navbar-brand" href="#" onclick="goBack()">
        <span class="glyphicon glyphicon-arrow-left"></span> Back
    </a>
</div>

    <div class="container">
        <div class="product">
            <img src="https://grandm.ch/img/products/normal/bild_dose600.jpg" alt="Burgerstein Microcare">
            <h3>Burgerstein Microcare</h3>
            <p>Description: This is a description of Burgerstein Microcare.</p>
            <button class="btn btn-primary buy-now-btn" onclick="buyNow('https://www.gall-shop.com/')">Buy Now</button>
        </div>

        <div class="product">
            <img src="https://grandm.ch/img/products/small/c-berry-4.jpg" alt="Burgerstein C-Berry">
            <h3>Burgerstein C-Berry</h3>
            <p>Description: This is a description of Burgerstein C-Berry.</p>
            <button class="btn btn-primary buy-now-btn" onclick="buyNow('https://www.gall-shop.com/')">Buy Now</button>
        </div>

        <div class="product">
            <img src="https://grandm.ch/img/products/small/immunvital-3.jpg" alt="Burgerstein ImmunVital">
            <h3>Burgerstein ImmunVital</h3>
            <p>Description: This is a description of Burgerstein ImmunVital.</p>
            <button class="btn btn-primary buy-now-btn" onclick="buyNow('https://www.gall-shop.com/')">Buy Now</button>
        </div>

        <div class="product">
            <img src="https://grandm.ch/img/products/normal/anti-ox-3.jpg" alt="Burgerstein Anti-Ox">
            <h3>Burgerstein Anti-Ox</h3>
            <p>Description: This is a description of Burgerstein Anti-Ox.</p>
            <button class="btn btn-primary buy-now-btn" onclick="buyNow('https://www.gall-shop.com/')">Buy Now</button>
        </div>

        <div class="product">
            <img src="https://grandm.ch/img/products/normal/aminovital-6.jpg" alt="Burgerstein Aminovital">
            <h3>Burgerstein Aminovital</h3>
            <p>Description: This is a description of Burgerstein Aminovital.</p>
            <button class="btn btn-primary buy-now-btn" onclick="buyNow('https://www.gall-shop.com/')">Buy Now</button>
        </div>

        <div class="product">
            <img src="https://grandm.ch/img/products/small/magnesiumvital-3.jpg" alt="Burgerstein Magnesiumvital">
            <h3>Burgerstein Magnesiumvital</h3>
            <p>Description: This is a description of Burgerstein Magnesiumvital.</p>
            <button class="btn btn-primary buy-now-btn" onclick="buyNow('https://www.amazon.in/s?k=Burgerstein-Magnesiumvital&crid=F0TUDHHGR07H&sprefix=burgerstein-magnesiumvital%2Caps%2C198&ref=nb_sb_noss')">Buy Now</button>
        </div>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script>
        function buyNow(url) {
            window.open(url, '_blank');
        }
            
    function goBack() {
        window.history.back();
    }

    </script>
</body>
</html>
