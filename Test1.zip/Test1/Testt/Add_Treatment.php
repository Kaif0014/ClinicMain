<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Treatments</title>
    <style>
        /* Add your CSS styles for the page here */
        body {
            font-family: Arial, sans-serif;
        }

        h1 {
            color: #007BFF;
            text-align: center;
            margin-top: 20px;
        }

        .container {
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
        }

        form {
            text-align: center;
        }

        .form-group {
            margin-bottom: 20px;
        }

        input, select {
            width: 35.5%;
            padding: 10px;
            border: 2px solid #007BFF;
            border-radius: 5px;
            font-size: 16px;
            outline: none;
        }

        .btn {
            background-color: #007BFF;
            color: white;
            border: none;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 0 20px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .btn:hover {
            background-color: #0056b3;
        }

        .view-feedback-btn {
            position: absolute;
            top: 20px;
            right: 20px;
        }

        .home-btn {
            background-color: #007BFF;
            color: white;
            border: none;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            font-size: 16px;
            margin-right: 20px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .home-btn:hover {
            background-color: #0056b3;
        }
        
        .qq{
        }
         .navbar {
            background-color: #333;
            color: white;
            padding: 10px 20px;
        }
        .navbar a {
            color: white;
            text-decoration: none;
            margin-right: 20px;
        }
        .home-btn {
            background-color: #007BFF;
            color: white;
            border: none;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .home-btn:hover {
            background-color: #0056b3;
        }

    .treatments-table {
        width: 100%;
        border-collapse: collapse;
    }

    .treatments-table th, .treatments-table td {
        border: 1px solid #ccc;
        padding: 10px;
        text-align: center;
    }

    .treatments-table th {
        background-color: #007BFF;
        color: white;
    }

    .treatments-table tr:nth-child(even) {
        background-color: #f2f2f2;
    }

    .treatments-table tr:nth-child(odd) {
        background-color: #ffffff;
    }

    .btn-container {
        display: flex;
        justify-content: space-around;
    }

    .btn-container form {
        display: inline-block;
    }

    .btn-container form input[type="submit"] {
        background-color: #007BFF;
        color: white;
        border: none;
        padding: 5px 10px;
        text-align: center;
        text-decoration: none;
        font-size: 14px;
        cursor: pointer;
        border-radius: 5px;
        transition: background-color 0.3s ease;
        margin-right: 5px;
    }

    .btn-container form input[type="submit"]:hover {
        background-color: #0056b3;
    }
</style>
</head>
<body>
    <br>
    
 <a class="home-btn" href="admin.php">Back to Admin</a>
    <h1>Add New Treatments</h1>
    <div class="container">
        <form action="process_add_treatment.php" method="post">
            <div class="form-group">
                <input type="text" id="treatment_name" name="treatment_name" placeholder="Treatment Name" required>
            </div>
            <div class="form-group">
                <input type="text" id="treatment_desc" name="treatment_desc" placeholder="Treatment Description" required>
            </div>
            <div class="form-group">
                <input type="number" id="cost" name="cost" placeholder="Cost" required>
            </div>
            <div class="form-group">
                <select id="dentist_id" name="dentist_id" required>
                    <option value="" selected disabled>Select Dentist</option>
                    <?php
                    // Fetch the list of dentists from the database and populate the dropdown
                    $host = "localhost";
                    $dbUsername = "root";
                    $dbPassword = "";
                    $dbname = "dbclinicmain";
                    $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);

                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    $sql = "SELECT Dentist_ID, Dentist_Name FROM tbl_dentist";
                    $result = $conn->query($sql);

                    if ($result !== false && $result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo '<option value="' . $row['Dentist_ID'] . '">' . $row['Dentist_Name'] . '</option>';
                        }
                    }
                    $conn->close();
                    ?>
                </select>
            </div>
            <button type="submit" class="btn" name="submit">Add Treatment</button>
        </form>
    </div>
    <div class="container">
    <h2>Available Treatments</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Treatment Name</th>
            <th>Description</th>
            <th>Cost</th>
            <th>Dentist</th>
            <th>Status</th>
            <th>Action</th>
        </tr>

        <?php
        // Database connection
        $host = "localhost";
        $dbUsername = "root";
        $dbPassword = "";
        $dbname = "dbclinicmain";
        $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Function to fetch and display treatment records
        function fetchAndDisplayTreatmentRecords($conn) {
            $sql = "SELECT T.Treatment_ID, T.Treatment_Name, T.Treatment_Desc, T.Cost, D.Dentist_Name, T.Status
                    FROM Tbl_Treatment T
                    JOIN tbl_dentist D ON T.Dentist_ID = D.Dentist_ID";

            $result = $conn->query($sql);

            if ($result !== false && $result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row["Treatment_ID"]) . "</td>";
                    echo "<td>" . htmlspecialchars($row["Treatment_Name"]) . "</td>";
                    echo "<td>" . htmlspecialchars($row["Treatment_Desc"]) . "</td>";
                    echo "<td>" . htmlspecialchars($row["Cost"]) . "</td>";
                    echo "<td>" . htmlspecialchars($row["Dentist_Name"]) . "</td>";
                    echo "<td>" . htmlspecialchars($row["Status"]) . "</td>";
                    echo "<td class='btn-container'>";
                    echo "<form action='update_delete_treatment.php' method='post'>";
                    echo "<input type='hidden' name='id' value='" . htmlspecialchars($row["Treatment_ID"]) . "'>";
                    echo "<input type='hidden' name='table' value='treatment'>";
                    echo "<input type='submit' name='action' value='Update' class='btn'>";
                    echo "<input type='submit' name='action' value='Delete' class='btn' onclick='return confirm(\"Are you sure you want to delete this treatment?\")'>";
                    echo "</form>";
                    echo "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='7'>No treatment records found.</td></tr>";
            }
        }

        // Call the function to fetch and display treatment records
        fetchAndDisplayTreatmentRecords($conn);

        // Close the database connection
        $conn->close();
        ?>
    </table>
</div>

</body>
</html>
