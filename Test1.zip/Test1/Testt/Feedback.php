<?php
session_start(); // Start or resume a session

$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "DBClinicmain";

// Create a connection to the database
$conn = mysqli_connect($host, $dbUsername, $dbPassword, $dbname);

// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Initialize variables for feedback
$patientID = "";
$feedbackComment = "";
$feedbackSubmitted = false; // Add a variable to track feedback submission

if (isset($_SESSION['userID'], $_SESSION['userName'])) {
    // Both $_SESSION['userID'] and $_SESSION['userName'] are set
    $patientID = $_SESSION['userID'];

    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["submit"])) {
        // Check if the form is submitted
        $feedbackComment = $_POST["comment"];

        // Insert feedback into the database
        $sql = "INSERT INTO Tbl_Feedback (Patient_ID, Comment, Date) VALUES ('$patientID', '$feedbackComment', NOW())";

        if (mysqli_query($conn, $sql)) {
            // Feedback submitted successfully
            $feedbackComment = ""; // Clear the comment input
            $feedbackSubmitted = true; // Set the flag to indicate submission
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    }
}

// Close the database connection
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Feedback</title>
    <style>
        /* Include your CSS styles here, or link to an external stylesheet */

        /* Use similar styles as the patient dashboard for consistency */
        /* ... Copy the CSS styles from your patient dashboard ... */
        /* Here's a simple example to get you started with styles: */

        /* Reset some default styles */
        body, h1, h2, p, ul, li {
            margin: 0;
            padding: 0;
        }

        /* Improved styling for the sidebar */
        .sidebar {
            height: 100%;
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #333;
            padding-top: 20px;
            transition: width 0.3s;
        }

        .sidebar h2 {
            color: white;
            text-align: center;
        }

        .sidebar ul {
            list-style-type: none;
            padding: 0;
        }

        .sidebar li {
            margin-bottom: 10px;
            text-align: center;
        }

        .sidebar a {
            display: block;
            text-decoration: none;
            color: white;
            padding: 10px;
            transition: background-color 0.3s;
        }

        .sidebar a:hover {
            background-color: #555;
        }

        /* Styling for the content area */
        .content {
            margin-left: 250px;
            padding: 20px;
        }

        .content h1 {
            font-size: 36px;
            margin-bottom: 20px;
        }

        /* Improved styling for patient details */
        .patient-details {
            background-color: #f7f7f7;
            border: 1px solid #ccc;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .patient-details h2 {
            font-size: 24px;
            margin-bottom: 10px;
        }

        .patient-details p {
            font-size: 16px;
            margin-bottom: 10px;
        }

        /* Feedback form styling */
        .feedback-form {
            background-color: #f7f7f7;
            border: 1px solid #ccc;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .feedback-form label {
            font-size: 16px;
            margin-bottom: 10px;
        }

        .feedback-form textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
        }

        .feedback-form button {
            background-color: #333;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .feedback-form button:hover {
            background-color: #555;
        }

        /* Popup message styling */
        .popup {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            padding: 20px;
            background-color: #fff;
            border: 1px solid #ccc;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
            z-index: 9999;
        }

        /* Responsive design for smaller screens */
        @media screen and (max-width: 768px) {
            .sidebar {
                width: 100px;
            }

            .content {
                margin-left: 100px;
            }

            .sidebar h2 {
                font-size: 20px;
            }

            .sidebar ul {
                padding-left: 20px;
            }

            .sidebar li {
                margin-bottom: 5px;
            }

            .sidebar a {
                padding: 5px;
            }

            .content h1 {
                font-size: 24px;
            }
        }
    </style>
</head>
<body>
    <!-- Your HTML code for the sidebar -->
    <div class="sidebar">
        <h2>Dashboard</h2>
               <ul>
            <li><a href="Test1.php">Back</a></li>
            <li><a href="Patient.php">Profile</a>
            <li><a href="Patient_Profile.php">Manage Profile</a></li>
            <li><a href="Browse_treatment.php">Browse Treatments</a></li>
            <li><a href="Appointments_history.php">Appointment History</a></li>
            <li><a href="Payment.php">Payment</a></li>
            <li><a href="Feedback.php">Feedback</a></li>
            <li><a href="Main.php">Logout</a></li>
        </ul><!-- Sidebar content similar to the patient dashboard -->
    </div>
    <div class="content">
        <h1>Submit Feedback</h1>
        <div class="feedback-form">
            <form method="POST" action="feedback.php">
                <label for="comment">Your Feedback:</label>
                <textarea name="comment" id="comment" rows="5" required><?php echo $feedbackComment; ?></textarea>
                <button type="submit" name="submit">Submit</button>
            </form>
        </div>
    </div>
    <div id="popup" class="popup">
        Feedback submitted successfully!
    </div>
    <script>
        // JavaScript to display the popup message
        if (<?php echo $feedbackSubmitted ? 'true' : 'false'; ?>) {
            document.getElementById("popup").style.display = "block";
            setTimeout(function () {
                document.getElementById("popup").style.display = "none";
            }, 3000); // Close the popup after 3 seconds
        }
    </script>
</body>
</html>
