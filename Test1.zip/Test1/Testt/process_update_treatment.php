<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the required fields are set
    if (isset($_POST["id"]) && isset($_POST["treatment_name"]) && isset($_POST["treatment_desc"]) && isset($_POST["cost"])) {
        $host = "localhost";
        $dbUsername = "root";
        $dbPassword = "";
        $dbName = "dbclinicmain";

        // Create a database connection
        $conn = new mysqli($host, $dbUsername, $dbPassword, $dbName);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Prepare and execute an SQL statement to update the treatment record
        $id = $_POST["id"];
        $treatment_name = $_POST["treatment_name"];
        $treatment_desc = $_POST["treatment_desc"];
        $cost = $_POST["cost"];

        $sql = "UPDATE tbl_treatment SET Treatment_Name = ?, Treatment_Desc = ?, Cost = ? WHERE Treatment_ID = ?";
        $stmt = $conn->prepare($sql);

        if ($stmt) {
            $stmt->bind_param("ssdi", $treatment_name, $treatment_desc, $cost, $id);
            $stmt->execute();

            if ($stmt->affected_rows > 0) {
                // Treatment record updated successfully
                header("Location: Add_treatment.php");
            } else {
                echo "Error updating treatment record: " . $stmt->error;
            }

            $stmt->close();
        } else {
            echo "Error: " . $conn->error;
        }

        // Close the database connection
        $conn->close();
    } else {
        echo "Incomplete data submitted for treatment update.";
    }
} else {
    // Redirect to the appropriate page if accessed through a different HTTP method
    header("Location: admin.php");
}
?>
