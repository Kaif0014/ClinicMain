<?php
// Database connection
$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "dbclinicmain";

$conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_POST['action'] === 'Update') {
    // Handle the update action
    $treatmentId = $_POST['id']; // Replace this with your input source

    // Redirect to update_treatment.php with the ID for editing
    header("Location: update_treatment.php?id=$treatmentId");
    exit;
}

// Disable foreign key checks
mysqli_query($conn, "SET FOREIGN_KEY_CHECKS=0");

// Perform the "hard delete" operation
$treatmentId = $_POST['id']; // Replace this with your input source
$sql = "DELETE FROM tbl_treatment WHERE Treatment_ID = $treatmentId";

if ($conn->query($sql) === TRUE) {
    echo "Treatment record deleted successfully.";
    header("Refresh: 2; URL=Add_treatment.php");
} else {
    echo "Error deleting treatment record: " . $conn->error;
}

// Re-enable foreign key checks
mysqli_query($conn, "SET FOREIGN_KEY_CHECKS=1");

// Close the database connection
$conn->close();
?>
