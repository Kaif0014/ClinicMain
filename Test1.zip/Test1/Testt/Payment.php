<?php
session_start(); // Start or resume a session

$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "DBClinicmain";

// Create a connection to the database
$conn = mysqli_connect($host, $dbUsername, $dbPassword, $dbname);

// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Initialize variables for patient details
$patientID = "";
$patientName = "";

if (isset($_SESSION['userID'], $_SESSION['userName'])) {
    // Both $_SESSION['userID'] and $_SESSION['userName'] are set
    $patientID = $_SESSION['userID'];
    $patientName = $_SESSION['userName'];

    // Fetch all completed appointments for the patient
$sql = "SELECT a.Appointment_ID, a.Treatment_ID, a.Date, t.Treatment_Name, t.Cost 
        FROM Tbl_Appointment a
        JOIN Tbl_Treatment t ON a.Treatment_ID = t.Treatment_ID
        LEFT JOIN Tbl_Payment p ON a.Appointment_ID = p.Appointment_ID
        WHERE a.Patient_ID = '$patientID' 
        AND a.Status = 'Completed' 
        AND (p.Status = 'Pending' OR p.Status IS NULL)";

    $result = mysqli_query($conn, $sql);
}

// Handle payment form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["submitPayment"])) {
    // Retrieve the payment form data
    $appointmentID = $_POST["appointmentID"];
    $cardNumber = $_POST["cardNumber"];
    $expirationDate = $_POST["expirationDate"];
    $cvv = $_POST["cvv"];

    // Perform payment processing (you need to implement this part)

    // For this example, we'll assume the payment was successful
    $paymentSuccessful = true;

    if ($paymentSuccessful) {
    // Update the appointment status to "Paid" in the database (you need to implement this part)
    $updateSql = "UPDATE Tbl_Payment SET Status = 'Paid' WHERE Appointment_ID = '$appointmentID'";
    if (mysqli_query($conn, $updateSql)) {
        // Payment successful
        // Set a flag to indicate successful payment
        $paymentSuccessFlag = true;
    } else {
        echo "Error updating appointment status: " . mysqli_error($conn);
    }
} else {
    echo "Payment failed. Please try again.";
}
}

// Close the database connection
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Make Payment</title>
    <style>
        body, h1, h2, p, ul, li {
            margin: 0;
            padding: 0;
        }

        /* Improved styling for the sidebar */
        .sidebar {
            height: 100%;
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #333;
            padding-top: 20px;
            transition: width 0.3s;
        }

        .sidebar h2 {
            color: white;
            text-align: center;
        }

        .sidebar ul {
            list-style-type: none;
            padding: 0;
        }

        .sidebar li {
            margin-bottom: 10px;
            text-align: center;
        }

        .sidebar a {
            display: block;
            text-decoration: none;
            color: white;
            padding: 10px;
            transition: background-color 0.3s;
        }

        .sidebar a:hover {
            background-color: #555;
        }

        /* Styling for the content area */
        .content {
            margin-left: 250px;
            padding: 20px;
        }

        .content h1 {
            font-size: 36px;
            margin-bottom: 20px;
        }

        /* Card styling for completed appointments */
        .appointment-card {
            background-color: #f7f7f7;
            border: 1px solid #ccc;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        .appointment-card h2 {
            font-size: 24px;
            margin-bottom: 10px;
        }

        .appointment-card p {
            font-size: 16px;
            margin-bottom: 10px;
        }

        .pay-button {
            background-color: #333;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .pay-button:hover {
            background-color: #555;
        }

        /* Responsive design for smaller screens */
        @media screen and (max-width: 768px) {
            .sidebar {
                width: 100px;
            }

            .content {
                margin-left: 100px;
            }

            .sidebar h2 {
                font-size: 20px;
            }

            .sidebar ul {
                padding-left: 20px;
            }

            .sidebar li {
                margin-bottom: 5px;
            }

            .sidebar a {
                padding: 5px;
            }

            .content h1 {
                font-size: 24px;
            }
        }
    </style>
    <script>
    // JavaScript function to display a pop-up message
     <?php
    if (isset($paymentSuccessFlag) && $paymentSuccessFlag) {
        echo "window.onload = function() { showSuccessPopupAndRedirect(); };";
    }
    ?>

    function showSuccessPopupAndRedirect() {
        if (confirm("Payment was successful. Thank you for your payment! Click 'OK' to proceed to your appointment historys.")) {
            window.location.href = "Appointments_history.php";
        }
    }
</script>

</head>
<body>
    <div class="sidebar">
        <h2>Dashboard</h2>
        <ul>
            <li><a href="Test1.php">Back</a></li>
            <li><a href="Patient.php">Profile</a>
            <li><a href="Patient_Profile.php">Manage Profile</a></li>
            <li><a href="Browse_treatment.php">Browse Treatments</a></li>
            <li><a href="Appointments_history.php">Appointment History</a></li>
            <li><a href="Payment.php">Payment</a></li>
            <li><a href="Feedback.php">Feedback</a></li>
            <li><a href="Main.php">Logout</a></li>
        </ul>
    </div>

    <div class="content">
        <h1>Make Payment</h1>
        <?php
        if (isset($result)) {
            while ($row = mysqli_fetch_assoc($result)) {
                echo '<div class="appointment-card">';
                echo '<h2>Appointment ID: ' . $row['Appointment_ID'] . '</h2>';
                echo '<p>Treatment: ' . $row['Treatment_Name'] . '</p>';
                echo '<p>Cost: ' . $row['Cost'] . ' Rs</p>';
                echo '<p>Date: ' . $row['Date'] . '</p>';
                echo '<form method="POST" action="payment.php">';
                echo '    <input type="hidden" name="appointmentID" value="' . $row['Appointment_ID'] . '">';
                echo '    <label for="cardNumber">Card Number:</label>';
                echo '    <input type="number" id="cardNumber" name="cardNumber" placeholder="Enter your card number" required>';
                echo '    <label for="expirationDate">Expiration Date:</label>';
                echo '    <input type="text" id="expirationDate" name="expirationDate" placeholder="MM/YY" required>';
                echo '    <label for "cvv">CVV:</label>';
                echo '    <input type="password" id="cvv" name="cvv" placeholder="Enter CVV" required>';
                echo '    <button type="submit" name="submitPayment" class="pay-button">Submit Payment</button>';
                echo '</form>';
                echo '</div>';
            }
        } else {
            echo "<p>No completed appointments found.</p>";
        }
        ?>
    </div>
    
</body>
</html>
