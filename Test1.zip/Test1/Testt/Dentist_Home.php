<?php
session_start(); // Start or resume a session

$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "dbclinicmain";

// Create a database connection
$conn = mysqli_connect($host, $dbUsername, $dbPassword, $dbname);

// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Initialize variables for dentist details
$dentistID = "";
$dentistName = "";
$dentistGender = "";
$dentistAddress = "";
$dentistEmail = "";
$dentistExp = "";
$dentistContactNo = "";
$dentistPassword = "";

if (isset($_SESSION['dentist_id'])) {
    $dentist_id = $_SESSION['dentist_id'];

    // Fetch dentist details based on the user's email
    $sql = "SELECT * FROM tbl_dentist WHERE Dentist_ID = '$dentist_id'";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        if (mysqli_num_rows($result) > 0) {
            // Dentist found, get their details
            $row = mysqli_fetch_assoc($result);
            $dentistID = htmlspecialchars($row["Dentist_ID"]);
            $dentistName = htmlspecialchars($row["Dentist_Name"]);
            $dentistGender = htmlspecialchars($row["Gender"]);
            $dentistAddress = htmlspecialchars($row["Address"]);
            $dentistExp = htmlspecialchars($row["Experience"]);
            $dentistContactNo = htmlspecialchars($row["Contact_No"]);
            $dentistPassword = htmlspecialchars($row["Password"]);
            $dentistEmail = htmlspecialchars($row["Email"]);
        } else {
            echo "<p>No dentist found with the provided email.</p>";
        }
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}

// Close the database connection
mysqli_close($conn);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Add your meta tags and title here -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dentist Dashboard</title>
    <style>
        /* Reset some default styles */
        body, h1, h2, p, ul, li {
            margin: 0;
            padding: 0;
        }

        /* Improved styling for the navbar */
        .navbar {
            background-color: #17a2b8;
            color: #fff;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
        }

        .navbar-brand {
            font-size: 24px;
            color: #fff;
        }

        .navbar-right {
            display: flex;
            align-items: center;
        }

        .dentist-welcome {
            color: #fff;
            margin-right: 10px;
        }

        .welcome-icon {
            color: #fff;
            font-size: 24px;
        }

        /* Improved styling for the sidebar */
        .sidebar {
            height: 100%;
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #333;
            padding-top: 20px;
            transition: width 0.3s;
        }

        .sidebar h2 {
            color: white;
            text-align: center;
        }

        .sidebar ul {
            list-style-type: none;
            padding: 0;
        }

        .sidebar li {
            margin-bottom: 10px;
            text-align: center;
        }

        .sidebar a {
            display: block;
            text-decoration: none;
            color: white;
            padding: 10px;
            transition: background-color 0.3s;
        }

        .sidebar a:hover {
            background-color: #555;
        }

        /* Styling for the content area */
        .content {
            margin-left: 250px;
            padding: 20px;
        }

        .content h1 {
            font-size: 36px;
            margin-bottom: 20px;
        }

        /* Attractive content styling */
        .welcome-section {
            background-color: #f7f7f7;
            border: 1px solid #ccc;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .welcome-section h2 {
            font-size: 24px;
            margin-bottom: 10px;
            color: #333;
        }

        .welcome-section p {
            font-size: 16px;
            margin-bottom: 10px;
            color: #555;
        }

        /* Dentist card styling */
        .dentist-card {
            border: 1px solid #ccc;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            background-color: #fff;
        }

        /* Toggle Availability button styling */
        .btn-toggle-availability {
            background-color: #007BFF;
            color: white;
            border: none;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease;
            margin-top: 20px;
        }

        .btn-toggle-availability:hover {
            background-color: #0056b3;
        }

        /* Responsive design for smaller screens */
        @media screen and (max-width: 768px) {
            .sidebar {
                width: 100px;
            }

            .content {
                margin-left: 100px;
            }

            .sidebar h2 {
                font-size: 20px;
            }

            .sidebar ul {
                padding-left: 20px;
            }

            .sidebar li {
                margin-bottom: 5px;
            }

            .sidebar a {
                padding: 5px;
            }

            .content h1 {
                font-size: 24px;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="navbar-left">
            <a class="navbar-brand" href="#">Bracewell Clinic</a>
        </div>
        <div class="navbar-right">
            <span class="dentist-welcome">Welcome,  <?php echo $dentistName; ?></span>
            <i class="welcome-icon fas fa-user"></i>
        </div>
    </nav>
    <!-- Your HTML code for the dashboard -->
    <div class="sidebar">
        <h2>Dashboard</h2>
        <ul>
            <li><a href="Dentist_Home.php">Home</a></li>
            <li><a href="Dentist_appointment.php">Appointments</a></li>
            <li><a href="Completed_Appointments.php">Completed Appointments</a></li>
            <li><a href="Dentist_patient.php">Patients</a></li>
            <li><a href="Dentist_Settings.php">Settings</a></li>
            <li><a href="Main.php">Logout</a></li>
        </ul>
    </div>
    <div class="content">
        <h1>Welcome, <?php echo $dentistName; ?>!</h1>
        <div class="welcome-section">
            <h2>Your Dentist Dashboard</h2>
            <p>Welcome to your dentist dashboard. You can manage appointments, view patient records, and configure settings from the sidebar navigation.</p>
        </div>

        <!-- Add the dentist card here -->
        <div class="dentist-card">
            <h2>Your Dentist Information</h2>
            <p><strong>Dentist ID:</strong> <?php echo $dentistID; ?></p>
            <p><strong>Name:</strong> <?php echo $dentistName; ?></p>
            <p><strong>Gender:</strong> <?php echo $dentistGender; ?></p>
            <p><strong>Experience:</strong> <?php echo $dentistExp.' Years'; ?></p>
            <p><strong>Address:</strong> <?php echo $dentistAddress; ?></p>
            <p><strong>Contact No:</strong> <?php echo $dentistContactNo; ?></p>
            <p><strong>Email:</strong> <?php echo $dentistEmail; ?></p>

            <!-- Add a button to toggle availability -->
            <button class="btn-toggle-availability">Toggle Availability</button>
        </div>
    </div>

    <script>
        // JavaScript to handle the availability toggle button
        document.querySelector('.btn-toggle-availability').addEventListener('click', () => {
            // Redirect to the PHP script for toggling availability
            window.location.href = 'toggle_availability.php';
        });
    </script>
</body>
</html>
