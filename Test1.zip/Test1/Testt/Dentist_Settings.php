<?php
session_start(); // Start or resume a session

$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "dbclinicmain";

// Create a database connection
$conn = mysqli_connect($host, $dbUsername, $dbPassword, $dbname);

// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Initialize variables for dentist details
$dentistID = "";
$dentistName = "";
$dentistGender = "";
$dentistAddress = "";
$dentistEmail = "";
$dentistContactNo = "";
$dentistPassword = "";

if (isset($_SESSION['dentist_id'])) {
    $dentist_id = $_SESSION['dentist_id'];

    // Fetch dentist details based on the user's email
    $sql = "SELECT * FROM tbl_dentist WHERE Dentist_ID = '$dentist_id'";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        if (mysqli_num_rows($result) > 0) {
            // Dentist found, get their details
            $row = mysqli_fetch_assoc($result);
            $dentistID = htmlspecialchars($row["Dentist_ID"]);
            $dentistName = htmlspecialchars($row["Dentist_Name"]);
            $dentistGender = htmlspecialchars($row["Gender"]);
            $dentistAddress = htmlspecialchars($row["Address"]);
            $dentistContactNo = htmlspecialchars($row["Contact_No"]);
            $dentistPassword = htmlspecialchars($row["Password"]);
            $dentistEmail = htmlspecialchars($row["Email"]);
        } else {
            echo "<p>No dentist found with the provided email.</p>";
        }
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
// Handle updating the dentist profile
if (isset($_POST['update_profile'])) {
    $newName = mysqli_real_escape_string($conn, $_POST['new_name']);
    $newAddress = mysqli_real_escape_string($conn, $_POST['new_address']);
    $newEmail = mysqli_real_escape_string($conn, $_POST['new_email']);
    $newContactNo = mysqli_real_escape_string($conn, $_POST['new_contact_no']);
    $newPassword = mysqli_real_escape_string($conn, $_POST['new_password']);
    $currentPassword = mysqli_real_escape_string($conn, $_POST['current_password']);

    // Check if the current password matches the one in the database
    if ($currentPassword === $dentistPassword) {
        // Update the dentist's profile with plain text password
        $updateSql = "UPDATE tbl_dentist
                     SET Dentist_Name = '$newName', 
                         Address = '$newAddress', 
                         Email = '$newEmail', 
                         Contact_No = '$newContactNo', 
                         Password = '$newPassword'
                     WHERE Dentist_ID = $dentistID";

        if (mysqli_query($conn, $updateSql)) {
            echo '<script>alert("Profile updated successfully.");</script>';
        } else {
            echo '<script>alert("Error updating profile: ' . mysqli_error($conn) . '");</script>';
        }
    } else {
        echo '<script>alert("Current password is incorrect. Profile not updated.");</script>';
    }
}


// Close the database connection
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Add your meta tags and title here -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dentist Settings</title>
    <style>
        /* Reset some default styles */
        body, h1, h2, p, ul, li {
            margin: 0;
            padding: 0;
        }

        /* Styling based on dentist_home.php */
        .navbar {
            background-color: #17a2b8;
            color: #fff;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
        }

        .navbar-brand {
            font-size: 24px;
            color: #fff;
        }

        .navbar-right {
            display: flex;
            align-items: center;
        }

        .dentist-welcome {
            color: #fff;
            margin-right: 10px;
        }

        .welcome-icon {
            color: #fff;
            font-size: 24px;
        }

        .sidebar {
            height: 100%;
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #333;
            padding-top: 20px;
            transition: width 0.3s;
        }

        .sidebar h2 {
            color: white;
            text-align: center;
        }

        .sidebar ul {
            list-style-type: none;
            padding: 0;
        }

        .sidebar li {
            margin-bottom: 10px;
            text-align: center;
        }

        .sidebar a {
            display: block;
            text-decoration: none;
            color: white;
            padding: 10px;
            transition: background-color 0.3s;
        }

        .sidebar a:hover {
            background-color: #555;
        }

        .content {
            margin-left: 250px;
            padding: 20px;
        }

        .content h1 {
            font-size: 36px;
            margin-bottom: 20px;
        }

        /* Form styling */
        form {
            background-color: #f7f7f7;
            border: 1px solid #ccc;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        form label {
            font-size: 16px;
        }

        form input {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        form button {
            background-color: #17a2b8;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="navbar-left">
            <a class="navbar-brand" href="#">Bracewell Clinic</a>
        </div>
        <div class="navbar-right">
            <span class="dentist-welcome">Welcome, <?php echo $dentistName; ?></span>
            <i class="welcome-icon fas fa-user"></i>
        </div>
    </nav>
    <div class="sidebar">
        <h2>Dashboard</h2>
        <ul>
            <li><a href="Dentist_Home.php">Home</a></li>
            <li><a href="Dentist_appointment.php">Appointments</a></li>
            <li><a href="Completed_Appointments.php">Completed Appointments</a></li>
            <li><a href="Dentist_patient.php">Patients</a></li>
            <li><a href="Dentist_Settings.php">Settings</a></li>
            <li><a href="Main.php">Logout</a></li>
        </ul>
    </div>
    <div class="content">
        <h1>Welcome, <?php echo $dentistName; ?>!</h1>
        <div class="welcome-section">
            <h2>Your Dentist Dashboard</h2>
            <p>Welcome to your dentist dashboard. You can manage appointments, view patient records, and configure settings from the sidebar navigation.</p>
        </div>
        <form method="POST">
            <h2>Update Your Profile</h2>
            <label for="new_name">Name:</label>
            <input type="text" id="new_name" name="new_name" value="<?php echo $dentistName; ?>" required><br>

            <label for="new_address">Address:</label>
            <input type="text" id="new_address" name="new_address" value="<?php echo $dentistAddress; ?>" required><br>

            <label for="new_email">Email:</label>
            <input type="email" id="new_email" name="new_email" value="<?php echo $dentistEmail; ?>" required><br>

            <label for="new_contact_no">Contact No:</label>
            <input type="text" id="new_contact_no" name="new_contact_no" value="<?php echo $dentistContactNo; ?>" required><br>

            <label for="current_password">Current Password:</label>
            <input type="password" id="current_password" name="current_password" required><br>

            <label for="new_password">New Password:</label>
            <input type="password" id="new_password" name="new_password" required><br>

            <button type="submit" name="update_profile">Update Profile</button>
        </form>
    </div>
</body>
</html>
