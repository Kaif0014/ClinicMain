<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dental Health Resources - Bracewell Clinic</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <!-- Add your custom stylesheets or styling here if needed -->
    <style>
        /* Add your additional styles here */
        body {
            background-color: #f8f8f8;
        }

        .container {
            margin-top: 20px;
        }

        .resource {
            background-color: #fff;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 5px;
        }

        h3 {
            color: #333;
        }

        p {
            color: #666;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-inverse">
        <div class="container-fluid">
            <!-- Back button -->
            <div class="navbar-header">
    <a class="navbar-brand" href="#" onclick="goBack()">
        <span class="glyphicon glyphicon-arrow-left"></span> Back
    </a>
</div>
            <!-- Add other navbar content here -->
        </div>
    </nav>

    <div class="container">
        <h2>Dental Health Resources</h2>

        <div class="resource">
            <h3>Dental Care Guide</h3>
            <p>Download our comprehensive dental care guide to learn about maintaining optimal oral health. It includes tips for daily care, preventive measures, and more.</p>
            <a href="path/to/dental_care_guide.pdf" download><button class="btn btn-primary">Download Guide</button></a>
        </div>

        <div class="resource">
            <h3>Post-Treatment Instructions</h3>
            <p>After undergoing dental treatment, it's essential to follow proper post-treatment instructions. Download our guide for detailed instructions and care tips.</p>
            <a href="path/to/post_treatment_instructions.pdf" download><button class="btn btn-primary">Download Instructions</button></a>
        </div>

        <div class="resource">
            <h3>Oral Health Maintenance Tips</h3>
            <p>Explore our tips for maintaining excellent oral health on a daily basis. Learn about the importance of regular brushing, flossing, and other key practices.</p>
            <a href="path/to/oral_health_maintenance_tips.pdf" download><button class="btn btn-primary">Download Tips</button></a>
        </div>

        <!-- Additional content -->
        
    </div>

    <!-- Add your footer content here -->

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script>
    function goBack() {
        window.history.back();
    }
</script>
</body>
</html>
