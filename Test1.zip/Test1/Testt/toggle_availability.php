<?php
session_start(); // Start or resume a session

$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "dbclinicmain";

// Create a database connection
$conn = mysqli_connect($host, $dbUsername, $dbPassword, $dbname);

// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_SESSION['dentist_id'])) {
    $dentist_id = $_SESSION['dentist_id'];

    // Check the current availability status
    $sql = "SELECT Status FROM Tbl_Availability WHERE Dentist_ID = '$dentist_id'";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        if (mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            $currentStatus = htmlspecialchars($row["Status"]);

            // Toggle the availability status
            $newStatus = ($currentStatus === "Available") ? "Unavailable" : "Available";

            // Update the availability status in the database
            $updateSql = "UPDATE Tbl_Availability SET Status = '$newStatus' WHERE Dentist_ID = '$dentist_id'";
            if (mysqli_query($conn, $updateSql)) {
                $message = "Availability status updated successfully.($newStatus)";
            } else {
                $message = "Error updating availability status: " . mysqli_error($conn);
            }
        } else {
            // No availability status found, set the initial status to "Unavailable"
            $initialStatus = "Unavailable";
            $insertSql = "INSERT INTO Tbl_Availability (Dentist_ID, Status) VALUES ('$dentist_id', '$initialStatus')";
            if (mysqli_query($conn, $insertSql)) {
                $message = "Availability status set to 'Unavailable'.";
            } else {
                $message = "Error setting initial availability status: " . mysqli_error($conn);
            }
        }
    } else {
        $message = "Error: " . mysqli_error($conn);
    }
}

// Close the database connection
mysqli_close($conn);
?>

<script>
    alert("<?php echo $message; ?>");
    window.location.href = "Dentist_Home.php";
</script>
