<?php
session_start();
$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "dbclinicmain";

// Create a database connection
$conn = mysqli_connect($host, $dbUsername, $dbPassword, $dbname);

// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_POST['completeAppointment'])) {
    $appointmentId = $_POST['appointmentId'];

    // Update the appointment status to 'Completed'
    $updateSql = "UPDATE tbl_appointment SET Status = 'Completed' WHERE Appointment_ID = '$appointmentId'";
    $updateResult = mysqli_query($conn, $updateSql);

    if ($updateResult) {
        // Redirect to the same page or another page after updating the status
        header("Location: Dentist_appointment.php");
        exit;
    } else {
        echo "Error updating appointment status: " . mysqli_error($conn);
    }
}


$dentist_id = $_SESSION['dentist_id'];

$searchDate = isset($_GET['searchDate']) ? $_GET['searchDate'] : null;
$todayAppointments = isset($_GET['todayAppointments']);

// Modify the SQL query to include the date conditions
if ($searchDate) {
    $sql = "SELECT a.Appointment_ID, p.Patient_Name, a.Date, a.Time, t.Treatment_Name, t.Dentist_ID, a.Status
            FROM tbl_appointment a
            JOIN tbl_treatment t ON a.Treatment_ID = t.Treatment_ID
            JOIN tbl_patient p ON a.Patient_ID = p.Patient_ID
            WHERE a.Status = 'Scheduled' AND t.Dentist_ID = '$dentist_id' AND a.Date = '$searchDate'";
} elseif ($todayAppointments) {
    $todayDate = date("Y-m-d");
    $sql = "SELECT a.Appointment_ID, p.Patient_Name, a.Date, a.Time, t.Treatment_Name, t.Dentist_ID, a.Status
            FROM tbl_appointment a
            JOIN tbl_treatment t ON a.Treatment_ID = t.Treatment_ID
            JOIN tbl_patient p ON a.Patient_ID = p.Patient_ID
            WHERE a.Status = 'Scheduled' AND t.Dentist_ID = '$dentist_id' AND a.Date = '$todayDate'";
} else {
    $sql = "SELECT a.Appointment_ID, p.Patient_Name, a.Date, a.Time, t.Treatment_Name, t.Dentist_ID, a.Status
            FROM tbl_appointment a
            JOIN tbl_treatment t ON a.Treatment_ID = t.Treatment_ID
            JOIN tbl_patient p ON a.Patient_ID = p.Patient_ID
            WHERE a.Status = 'Scheduled' AND t.Dentist_ID = '$dentist_id'";
}

$result = mysqli_query($conn, $sql);

$acceptedAppointments = array(); // Initialize the array

if ($result) {
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $acceptedAppointments[] = $row;
        }
    } else {
        echo "<p>No accepted appointments found.</p>";
    }
} else {
    echo "Error: " . mysqli_error($conn);
}

// Close the database connection
mysqli_close($conn);
?>

<!-- ... (HTML code) -->


<!DOCTYPE html>
<html lang="en">
<head>
    <!-- ... (previous code for the head section) --><meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dentist Appointments</title>
    <style>
        /* Reset some default styles */
        body, h1, h2, p, ul, li {
            margin: 0;
            padding: 0;
        }

        /* Improved styling for the navbar */
       
        .dentist-welcome {
            color: #fff;
            margin-right: 10px;
        }

        .welcome-icon {
            color: #fff;
            font-size: 24px;
        }

        /* Improved styling for the sidebar */
        .sidebar {
            height: 100%;
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #333;
            padding-top: 20px;
            transition: width 0.3s;
        }

        .sidebar h2 {
            color: white;
            text-align: center;
        }

        .sidebar ul {
            list-style-type: none;
            padding: 0;
        }

        .sidebar li {
            margin-bottom: 10px;
            text-align: center;
        }

        .sidebar a {
            display: block;
            text-decoration: none;
            color: white;
            padding: 10px;
            transition: background-color 0.3s;
        }

        .sidebar a:hover {
            background-color: #555;
        }

        /* Styling for the content area */
        .content {
            margin-left: 250px;
            padding: 20px;
        }

        .content h1 {
            font-size: 36px;
            margin-bottom: 20px;
        }

        /* Attractive content styling */
        .welcome-section {
            background-color: #f7f7f7;
            border: 1px solid #ccc;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .welcome-section h2 {
            font-size: 24px;
            margin-bottom: 10px;
            color: #333;
        }

        .welcome-section p {
            font-size: 16px;
            margin-bottom: 10px;
            color: #555;
        }

        /* Responsive design for smaller screens */
        @media screen and (max-width: 768px) {
            .sidebar {
                width: 100px;
            }

            .content {
                margin-left: 100px;
            }

            .sidebar h2 {
                font-size: 20px;
            }

            .sidebar ul {
                padding-left: 20px;
            }

            .sidebar li {
                margin-bottom: 5px;
            }

            .sidebar a {
                padding: 5px;
            }

            .content h1 {
                font-size: 24px;
            }
        }
        table {
        font-size: 18px;
        width: 100%;
        border-collapse: collapse;
    }

    th, td {
        padding: 10px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }

    th {
        background-color: #f2f2f2;
    }
    </style>
</head>
<body>
   
    <div class="sidebar">
        <h2>Dashboard</h2>
        <ul>
            <li><a href="Dentist_Home.php">Home</a></li>
            <li><a href="Dentist_appointment.php">Appointments</a></li>
            <li><a href="Completed_Appointments.php">Completed Appointments</a></li>
            <li><a href="Dentist_patient.php">Patients</a></li>
            <li><a href="Dentist_Settings.php">Settings</a></li>
            <li><a href="Main.php">Logout</a></li>
        </ul>
    </div>
    <div class="content">
        <h1>Appointments</h1>
        <div class="welcome-section">
            <?php if (!empty($acceptedAppointments)) { ?>
            <div class="search-section">
    <form method="get" style="display: inline-block;">
        <label for="searchDate">Search Appointments by Date:</label>
        <input type="date" name="searchDate" id="searchDate">
        <input type="submit" value="Search">
    </form>

    <form method="get" style="display: inline-block; margin-left: 10px;">
        <input type="submit" name="todayAppointments" value="Today's Appointments">
    </form>
</div>


    <table>
        <tr>
            <th>Appointment ID</th>
            <th>Patient Name</th>
            <th>Appointment Date</th>
            <th>Appointment Time</th>
            <th>Treatment Name</th>
            <th>Action</th> <!-- New column for the button -->
        </tr>
        <?php foreach ($acceptedAppointments as $appointment) { ?>
            <tr>
                <td><?php echo $appointment['Appointment_ID']; ?></td>
                <td><?php echo $appointment['Patient_Name']; ?></td>
                <td><?php echo $appointment['Date']; ?></td>
                <td><?php echo $appointment['Time']; ?></td>
                <td><?php echo $appointment['Treatment_Name']; ?></td>
                <td>
                    <?php if ($appointment['Status'] === 'Scheduled') { ?>
                        <form method="post">
                            <input type="hidden" name="completeAppointment" value="1">
                            <input type="hidden" name="appointmentId" value="<?php echo $appointment['Appointment_ID']; ?>">
                            <input type="submit" value="Check as Completed">
                        </form>

                    <?php } else { ?>
                        Status: <?php echo $appointment['Status']; ?>
                    <?php } ?>
                </td>
            </tr>
        <?php } ?>
    </table>

   <?php } else {
    echo "<p>No accepted appointments found.</p>";
    echo '<form method="get">
              <input type="submit" name="refreshAppointments" value="Back">
          </form>';
} ?> <!-- ... (previous code for the closing body and HTML tags) -->
</body>
</html>
