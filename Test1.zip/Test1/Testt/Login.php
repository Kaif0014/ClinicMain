<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bracewell Clinic Login</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <style>
        /* Custom Styles */
        body {
            background-color: #f5f5f5;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .navbar {
            background-color: #17a2b8; /* Dentist-specific color, you can change it */
            color: #fff;
        }

        .navbar-brand {
            font-size: 24px;
            color: #fff;
        }

        .container {
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            padding: 20px;
            margin: 20px auto;
            max-width: 400px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            font-weight: bold;
        }

        .form-control {
            border: 2px solid #17a2b8; /* Dentist-specific color, you can change it */
            border-radius: 5px;
        }

        .btn {
            background-color: #17a2b8; /* Dentist-specific color, you can change it */
            color: #fff;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            cursor: pointer;
        }

        .btn:hover {
            background-color: #117a8b; /* Darker color on hover */
        }

        /* Style for the Show/Hide Password button */
        .password-toggle-btn {
            position: absolute;
            top: 75%; /* Center vertically */
            right: 10px;
            transform: translateY(-50%); /* Center vertically */
            cursor: pointer;
        }

        /* Style for the Password input */
        .password-input {
            padding-right: 35px;
        }

        /* Style for the Admin Login button */
        .admin-login-btn {
    background-color: #000; /* Black color */
    color: #fff; /* White text */
    border: none;
    border-radius: 5px;
    padding: 10px 20px;
    cursor: pointer;
    position: absolute;
    top: 10px; /* Adjust the top position as needed */
    right: 10px;
}

.admin-login-btn:hover {
    background-color: #333; /* Darker black on hover */
}


        /* Style for the tabs */
        .nav-tabs {
            border-bottom: 2px solid #17a2b8; /* Dentist-specific color, you can change it */
        }

        .nav-link {
            color: #17a2b8; /* Dentist-specific color, you can change it */
        }

        .nav-link.active {
            color: #fff;
            background-color: #17a2b8; /* Dentist-specific color, you can change it */
            border-radius: 5px 5px 0 0;
        }

        /* Style for the New Account link */
        .new-account-link {
            text-align: center;
            margin-top: 20px;
            font-weight: bold;
        }

        .new-account-link a {
            color: #17a2b8; /* Dentist-specific color, you can change it */
            text-decoration: none;
        }

        .new-account-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar">
        <div class="container-fluid">
            <a class="navbar-brand" href="Main.php">Bracewell Clinic</a>
            <!-- Admin Login button to the top right -->
            <button class="admin-login-btn" data-toggle="modal" data-target="#adminPasswordModal">Admin Login</button>
        </div>
    </nav>

    <div class="container">
        <h2 class="mt-4">Clinic Login</h2>
        
        <!-- Tabs for Patient, Receptionist, and Dentist logins -->
        <ul class="nav nav-tabs" id="myTabs">
            <li class="nav-item">
                <a class="nav-link active" id="patient-tab" data-toggle="tab" href="#patient-login">Patient</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="receptionist-tab" data-toggle="tab" href="#receptionist-login">Receptionist</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="dentist-tab" data-toggle="tab" href="#dentist-login">Dentist</a>
            </li>
        </ul>

        <!-- Tab content -->
        <div class="tab-content">
            <!-- Patient Login Form -->
            <div id="patient-login" class="tab-pane fade show active">
                <form action="process_login.php" method="post">
                    <div class="form-group">
                        <label for="patient-email">Email:</label>
                        <input type="email" class="form-control" id="patient-email" name="email" required>
                    </div>
                    <div class="form-group position-relative">
                        <label for="patient-password">Password:</label>
                        <input type="password" class="form-control password-input" id="patient-password" name="password" required>
                        <span class="password-toggle-btn" onclick="togglePasswordVisibility('patient-password', 'patient-toggleIcon')">
                            <i class="fas fa-eye-slash" id="patient-toggleIcon"></i>
                        </span>
                    </div>
                    <div class="row">
                        <div class="col-6 text-left">
                            <button type="submit" class="btn">Login</button>
                        </div>
                        <div class="col-6 text-right">
                            <a href="forget_password.php" class="btn btn-link" style="font-size: 15px;">Forgot Password?</a>
                        </div>
                    </div>
                </form>

                <!-- New Account Link -->
                <div class="new-account-link">
                    Don't have an account? <a href="new_reg.php">New Account?</a>
                </div>
            </div>

            <!-- Receptionist Login Form -->
            <div id="receptionist-login" class="tab-pane fade">
                <form action="Receptionist_login_process.php" method="post">
                    <div class="form-group">
                        <label for="receptionist-email">Email:</label>
                        <input type="email" class="form-control" id="receptionist-email" name="email" required>
                    </div>
                    <div class="form-group position-relative">
                        <label for="receptionist-password">Password:</label>
                        <input type="password" class="form-control password-input" id="receptionist-password" name="password" required>
                        <span class="password-toggle-btn" onclick="togglePasswordVisibility('receptionist-password', 'receptionist-toggleIcon')">
                            <i class="fas fa-eye-slash" id="receptionist-toggleIcon"></i>
                        </span>
                    </div>
                    <div class="text-left">
                        <button type="submit" class="btn">Login</button>
                    </div>
                </form>
            </div>

            <!-- Dentist Login Form -->
            <div id="dentist-login" class="tab-pane fade">
                <form action="Dentist_login_process.php" method="post">
                    <div class="form-group">
                        <label for="dentist-email">Email:</label>
                        <input type="email" class="form-control" id="dentist-email" name="email" required>
                    </div>
                    <div class="form-group position-relative">
                        <label for="dentist-password">Password:</label>
                        <input type="password" class="form-control password-input" id="dentist-password" name="password" required>
                        <span class="password-toggle-btn" onclick="togglePasswordVisibility('dentist-password', 'dentist-toggleIcon')">
                            <i class="fas fa-eye-slash" id="dentist-toggleIcon"></i>
                        </span>
                    </div>
                    <div class="text-left">
                        <button type="submit" class="btn">Login</button>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Admin Password Modal -->
        <div class="modal" id="adminPasswordModal">
            <div class="modal-dialog">
                <div class="modal-content">

                    <!-- Modal Header -->
                    <div class="modal-header">
                        <h4 class="modal-title">Admin Login</h4>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>

                    <!-- Modal Body -->
                    <div class="modal-body">
                        <label for="adminPassword">Password:</label>
                        <input type="password" class="form-control" id="adminPassword" required>
                        <button type="button" class="btn btn-primary mt-2" onclick="checkAdminPassword()">Login</button>
                    </div>

                    <!-- Modal Footer -->


                </div>
            </div>
        </div>
    </div>

    <!-- JavaScript and Bootstrap scripts (add these if not already included) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        // Function to toggle password visibility
        function togglePasswordVisibility(passwordId, toggleIconId) {
            const passwordInput = document.getElementById(passwordId);
            const toggleIcon = document.getElementById(toggleIconId);
            
            if (passwordInput.type === "password") {
                passwordInput.type = "text";
                toggleIcon.className = "fas fa-eye";
            } else {
                passwordInput.type = "password";
                toggleIcon.className = "fas fa-eye-slash";
            }
        }

        // Function to check the Admin Password
        function checkAdminPassword() {
            const enteredPassword = $('#adminPassword').val();
            // Replace 'yourAdminPassword' with the actual admin password
            if (enteredPassword === '123') {
                // Redirect to the admin login page
                window.location.href = 'admin.php';
            } else {
                alert('Invalid admin password. Please try again.');
                $('#adminPassword').val('');
            }
        }
    </script>
</body>
</html>
