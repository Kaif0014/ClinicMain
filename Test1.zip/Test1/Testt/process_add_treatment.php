<?php
// Check if the form is submitted
if (isset($_POST['submit'])) {
    $treatmentName = $_POST['treatment_name'];
    $treatmentDesc = $_POST['treatment_desc'];
    $cost = $_POST['cost'];
    $dentistID = $_POST['dentist_id'];

    // Validate the input (you can add more validation)


    // Database connection
    $host = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbname = "dbclinicmain";
    $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Insert the new treatment into the database
    $sql = "INSERT INTO Tbl_Treatment (Treatment_Name, Treatment_Desc, Cost, Dentist_ID, Status)
            VALUES (?, ?, ?, ?, 'Active')";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssdi", $treatmentName, $treatmentDesc, $cost, $dentistID);

    if ($stmt->execute()) {
        // Treatment added successfully
        header("Location: Add_treatment.php?success=Treatment added successfully");
    } else {
        // Handle database error
        header("Location: Asd_treatment.php?error=Database error: " . $conn->error);
    }

    $stmt->close();
    $conn->close();
} else {
    // Redirect to the add_treatments.php page if the form is not submitted
    header("Location: add_treatments.php");
}
?>
