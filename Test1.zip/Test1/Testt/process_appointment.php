<?php
$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "dbclinicmain";

// Create a database connection
$conn = mysqli_connect($host, $dbUsername, $dbPassword, $dbname);

// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$sql1 = "SELECT Patient_ID FROM patient";
$result1 = mysqli_query($conn, $sql1);

if (mysqli_num_rows($result1) > 0) {
    // Assuming there is only one row in the result, you can fetch the Patient_ID
    // If there can be multiple rows, you'll need to specify which one you want to store in $a
    $row = mysqli_fetch_assoc($result1);
    $a = $row["Patient_ID"];
} else {
    echo "No patients found in the database.";
}

// Get data from the form
$appointment_date = $_POST['appointment_date'];
$appointment_time = $_POST['appointment_time'];
$description = $_POST['description'];
$price = $_POST['price'];
$patient_id = $a;
$dentist_id = 1;

// Check if there's an existing appointment at the same date and time
$sql_check_existing = "SELECT * FROM appointment WHERE Appointment_Date = '$appointment_date' AND Appointment_Time = '$appointment_time'";
$result_check_existing = $conn->query($sql_check_existing);

if ($result_check_existing->num_rows > 0) {
    // An appointment already exists at the same date and time
    echo "An appointment already exists at this date and time.";
} else {
    // Insert the new appointment into the database
    // Insert the new appointment into the database with status set to "Pending"
$sql_insert_appointment = "INSERT INTO appointment (Patient_ID, Dentist_ID, Appointment_Date, Appointment_Time, Description, Price, Status)
VALUES ($patient_id, $dentist_id, '$appointment_date', '$appointment_time', '$description', $price, 'Pending')";


    if (mysqli_query($conn, $sql_insert_appointment)) {
        // Appointment scheduled successfully. Redirect to Browse_appointment.php
        header("Location: Browse_treatment.php");
        exit(); // Make sure to exit to prevent further code execution
    } else {
        echo "Error: " . $sql_insert_appointment . "<br>" . mysqli_error($conn);
    }
}

// Close the database connection
mysqli_close($conn);
?>
