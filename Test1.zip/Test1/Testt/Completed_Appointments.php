<?php
session_start(); // Start or resume a session

$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "dbclinicmain";

// Create a database connection
$conn = mysqli_connect($host, $dbUsername, $dbPassword, $dbname);

// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_SESSION['dentist_id'])) {
    $dentist_id = $_SESSION['dentist_id'];

    // Query to fetch completed appointments assigned to the logged-in dentist
    $sql = "SELECT 
                a.Appointment_ID, 
                a.Date, 
                p.Patient_Name, 
                t.Treatment_Name, 
                t.Treatment_Desc, 
                p.Gender AS Patient_Gender, 
                p.DOB, 
                p.Address AS Patient_Address, 
                p.Email AS Patient_Email, 
                p.Contact_No AS Patient_Contact_No, 
                t.Cost, 
                a.Status AS Appointment_Status
            FROM Tbl_Appointment a
            INNER JOIN Tbl_Patient p ON a.Patient_ID = p.Patient_ID
            INNER JOIN Tbl_Treatment t ON a.Treatment_ID = t.Treatment_ID
            WHERE t.Dentist_ID = '$dentist_id' AND a.Status = 'Completed'";

    $result = mysqli_query($conn, $sql);
    ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Add your meta tags and title here -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Completed Appointments</title>
    <style>
        /* Reset some default styles */
        body, h1, h2, p, ul, li {
            margin: 0;
            padding: 0;
        }

        /* Improved styling for the navbar */
        .navbar {
            background-color: #17a2b8;
            color: #fff;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
        }

        .navbar-brand {
            font-size: 24px;
            color: #fff;
        }

        .navbar-right {
            display: flex;
            align-items: center;
        }

        .dentist-welcome {
            color: #fff;
            margin-right: 10px;
        }

        .welcome-icon {
            color: #fff;
            font-size: 24px;
        }

        /* Improved styling for the sidebar */
        .sidebar {
            height: 100%;
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #333;
            padding-top: 20px;
            transition: width 0.3s;
        }

        .sidebar h2 {
            color: white;
            text-align: center;
        }

        .sidebar ul {
            list-style-type: none;
            padding: 0;
        }

        .sidebar li {
            margin-bottom: 10px;
            text-align: center;
        }

        .sidebar a {
            display: block;
            text-decoration: none;
            color: white;
            padding: 10px;
            transition: background-color 0.3s;
        }

        .sidebar a:hover {
            background-color: #555;
        }

        /* Styling for the content area */
        .content {
            margin-left: 250px;
            padding: 20px;
        }

        .content h1 {
            font-size: 36px;
            margin-bottom: 20px;
        }

        /* Styling for the appointment cards */
        .appointment-card {
            border: 1px solid #ccc;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            background-color: #fff;
            margin-bottom: 20px;
        }

        .appointment-card h2 {
            font-size: 24px;
            margin-bottom: 10px;
            color: #333;
        }

        .appointment-card p {
            font-size: 16px;
            margin-bottom: 10px;
            color: #555;
        }
    </style>
</head>
<body>

    <div class="sidebar">
        <h2>Dashboard</h2>
        <ul>
            <li><a href="Dentist_Home.php">Home</a></li>
            <li><a href="Dentist_appointment.php">Appointments</a></li>
            <li><a href="Completed_Appointments.php">Completed Appointments</a></li>
            <li><a href="Dentist_patient.php">Patients</a></li>
            <li><a href="Dentist_Settings.php">Settings</a></li>
            <li><a href="Main.php">Logout</a></li>
        </ul>
    </div>
    
    <div class="content">
        <h1>Completed Appointments</h1>
        <div class="search-filter-section">
    <select id="filterCriteria">
        <option value="all">All</option>
        <option value="Appointment_ID">Appointment ID</option>
        <option value="Date">Date</option>
        <option value="Patient_Name">Patient Name</option>
        <option value="Patient_Gender">Patient Gender</option>
        <option value="DOB">Date of Birth</option>
        <option value="Patient_Address">Patient Address</option>
        <option value="Patient_Email">Patient Email</option>
        <option value="Patient_Contact_No">Patient Contact No</option>
        <option value="Treatment_Name">Treatment Name</option>
        <option value="Treatment_Desc">Treatment Description</option>
        <option value="Cost">Treatment Cost</option>
        <option value="Appointment_Status">Appointment Status</option>
    </select>
    <input type="text" id="filterValue" placeholder="Enter value to filter">
</div>
        <?php
        if ($result && mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
            echo '<div class="appointment-card">';
            echo '<h2>Appointment ID: ' . $row['Appointment_ID'] . '</h2>';
            echo '<p>Date: ' . $row['Date'] . '</p>';
            echo '<p>Patient Name: ' . $row['Patient_Name'] . '</p>';
            echo '<p>Patient Gender: ' . $row['Patient_Gender'] . '</p>';
            echo '<p>Date of Birth: ' . $row['DOB'] . '</p>';
            echo '<p>Patient Address: ' . $row['Patient_Address'] . '</p>';
            echo '<p>Patient Email: ' . $row['Patient_Email'] . '</p>';
            echo '<p>Patient Contact No: ' . $row['Patient_Contact_No'] . '</p>';
            echo '<p>Treatment Name: ' . $row['Treatment_Name'] . '</p>';
            echo '<p>Treatment Description: ' . $row['Treatment_Desc'] . '</p>';
            echo '<p>Treatment Cost: ' . $row['Cost'] . '</p>';
            echo '<p>Appointment Status: ' . $row['Appointment_Status'] . '</p>';
            echo '</div>';
        }
        } else {
            echo "<p>No completed appointments found for the logged-in dentist.</p>";
        }
        ?>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function () {
        // Filter appointments when Apply Filter button is clicked
        $("#filterCriteria, #filterValue").on("input", function () {
    var criteria = $("#filterCriteria").val();
    var filterValue = $("#filterValue").val().toLowerCase();

    $(".appointment-card").each(function () {
        var appointmentData = "";

        switch (criteria) {
            case "all":
                appointmentData = $(this).text().toLowerCase();
                break;
            case "Appointment_ID":
            case "Patient_Gender":
            case "Patient_Address":
                appointmentData = $(this).find("p." + criteria).text().toLowerCase();
                break;
            default:
                // Do nothing for other criteria
                break;
        }

        if (criteria === "all" || appointmentData.includes(filterValue)) {
            $(this).show();
        } else {
            $(this).hide();
        }
    });
});


    });
</script>
</body>
</html>
<?php
} else {
    // Redirect to login page if the dentist is not logged in
    header("Location: login.php");
}

// Close the database connection
mysqli_close($conn);
?>
