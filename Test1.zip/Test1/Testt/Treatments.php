<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Treatments</title>
    <style>
        /* Center the h2, set font, and make it slightly bold */
        h2 {
            text-align: center;
            font-family: 'Arial', sans-serif;
            font-weight: 600;
            margin-top: 40px;
            color: #333; /* Adjust the color to your preference */
        }

        .navbar {
            margin-bottom: 0;
            border-radius: 0;
        }

        .navbar-inverse {
            background-color: #333;
            border-color: transparent;
        }

        .navbar-brand {
            font-size: 28px;
            color: #fff;
        }

        .navbar-nav > li > a {
            font-size: 18px;
            color: #fff;
        }

        /* Reset some default styles */
        body, h1, h2, p, ul, li {
            margin: 0;
            padding: 0;
        }

        /* Styling for the cards */
        .cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            justify-content: center;
            padding: 20px;
        }

        .card {
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            text-align: center;
            display: flex;
            flex-direction: column;
            transition: transform 0.3s; /* Add a smooth transition on hover */
            background: #f8f8f8;
        }

        /* Improved styling for card content */
        .card h2 {
            font-size: 24px; /* Increase font size for the title */
            margin-bottom: 10px;
            color: #333;
        }

        .card p {
            font-size: 16px;
            margin-bottom: 10px;
            color: #555;
        }

        .card strong {
            color: #333;
        }

        .card img {
            object-fit: cover;
            max-height: 200px;
            width: 100%;
            border-top-left-radius: 5px;
            border-top-right-radius: 5px;
        }

        /* Add a hover effect to cards */
        .card:hover {
            transform: scale(1.05);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }

        /* Footer styles */
        footer {
            text-align: center;
            background-color: #333;
            border-color: transparent;
            color: #fff;
            padding: 10px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-inverse">
        <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand" href="Main.php">Bracewell Clinic</a>
            </div>
            <ul class="nav navbar-nav">
                <li><a href="Main.php">Home</a></li>
                <li class="active"><a href="Treatments.php">Treatments</a></li>
                <li><a href="new_reg.php">New Patients</a></li>
                <li><a href="Login.php">Login</a></li>
               
            </ul>
        </div>
    </nav>

    <h2>Treatments</h2>

    <div class="cards">
        <?php
        // Database connection (replace with your actual connection code)
        $host = "localhost";
        $dbUsername = "root";
        $dbPassword = "";
        $dbname = "dbclinicmain";
        $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);

        // Check if the connection was successful
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Fetch treatment data from the database
        $sql = "SELECT * FROM tbl_treatment";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo '<div class="card">';
                echo '<h2>' . $row['Treatment_Name'] . '</h2>';
                echo '<p><strong>Description:</strong> ' . $row['Treatment_Desc'] . '</p>';
                echo '<p><strong>Price:</strong> ' . $row['Cost'] . 'Rs</p>';
                // You can add more fields here as needed

                // If you have a Dentist_ID associated with the treatment, you can fetch necessary dentist details too

                echo '</div>';
            }
        } else {
            echo "No treatments available.";
        }

        // Close the database connection
        $conn->close();
        ?>
    </div>

    <footer style="text-align: center; background-color: #333;
            border-color: transparent; color: #fff; padding: 10px;">
        Bracewell Clinic: For Appointments, Please <a href="Login.php" style="color: #fff; text-decoration: underline;">Log In</a>
    </footer>
</body>
</html>
