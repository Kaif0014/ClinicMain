<?php
$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "dbclinicmain";

// Create a database connection
$conn = mysqli_connect($host, $dbUsername, $dbPassword, $dbname);

// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_POST['accept'])) {
    $appointment_id = $_POST['appointment_id'];
    // Update the status to 'Scheduled' for the selected appointment
    $sql_update = "UPDATE tbl_appointment SET Status = 'Scheduled' WHERE Appointment_ID = $appointment_id";
    mysqli_query($conn, $sql_update);
    header("Refresh:0");
}

if (isset($_POST['reject'])) {
    $appointment_id = $_POST['appointment_id'];
    // Update the status to 'Canceled' for the selected appointment
    $sql_update = "UPDATE tbl_appointment SET Status = 'Canceled' WHERE Appointment_ID = $appointment_id";
    mysqli_query($conn, $sql_update);
    header("Refresh:0");
}

// Retrieve data for appointments to review (Pending and Canceled)
$sql_select_pending_canceled = "SELECT a.Appointment_ID, a.Patient_ID, a.Date, a.Time, a.Status, t.Treatment_Name, t.Treatment_Desc, p.Patient_Name
              FROM tbl_appointment a
              INNER JOIN Tbl_Treatment t ON a.Treatment_ID = t.Treatment_ID
              INNER JOIN Tbl_Patient p ON a.Patient_ID = p.Patient_ID
              WHERE a.Status = 'Pending'";

$result_pending_canceled = mysqli_query($conn, $sql_select_pending_canceled);
$sql_select_canceled = "SELECT a.Appointment_ID, a.Patient_ID, a.Date, a.Time, a.Status, t.Treatment_Name, t.Treatment_Desc, p.Patient_Name
              FROM tbl_appointment a
              INNER JOIN Tbl_Treatment t ON a.Treatment_ID = t.Treatment_ID
              INNER JOIN Tbl_Patient p ON a.Patient_ID = p.Patient_ID
              WHERE a.Status = 'Canceled'";
$result_canceled = mysqli_query($conn, $sql_select_canceled);
// Retrieve data for scheduled appointments
$sql_select_scheduled = "SELECT a.Appointment_ID, a.Patient_ID, a.Date, a.Time, a.Status, t.Treatment_Name, t.Treatment_Desc,d.Dentist_ID, d.Dentist_Name, p.Patient_Name
                     FROM tbl_appointment a
                     INNER JOIN Tbl_Treatment t ON a.Treatment_ID = t.Treatment_ID
                     INNER JOIN Tbl_Dentist d ON t.Dentist_ID = d.Dentist_ID
                     INNER JOIN Tbl_Patient p ON a.Patient_ID = p.Patient_ID
                     WHERE a.Status = 'Scheduled'";
$result_scheduled = mysqli_query($conn, $sql_select_scheduled);

// Retrieve data for completed treatments
$sql_select_completed = "SELECT a.Appointment_ID, a.Patient_ID, a.Date, a.Time, a.Status, t.Treatment_Name, t.Treatment_Desc, p.Patient_Name
              FROM tbl_appointment a
              INNER JOIN Tbl_Treatment t ON a.Treatment_ID = t.Treatment_ID
              INNER JOIN Tbl_Patient p ON a.Patient_ID = p.Patient_ID
              WHERE a.Status = 'Completed'";
$result_completed = mysqli_query($conn, $sql_select_completed);

// Close the database connection
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receptionist Page</title>
       <style>
        h1{
            text-align: center;
        }
        table 
        {
            border-collapse: collapse;
            width: 62%; /* Reduce the width of the table */
            margin: 0 auto; /* Center the table horizontally */
        }

        .table-container {
            text-align: right;
            margin-right: 20px; /* You can adjust the margin as needed */
            display: inline-block;
            text-align: center;
        }
        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #333;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        /* Reset some default styles */
        body, h1, h2, p, ul, li {
            margin: 0;
            padding: 0;
        }

        /* Styling for the sidebar (same as the dashboard) */
        .sidebar {
            height: 100%;
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #333;
            padding-top: 20px;
            transition: width 0.3s;
        }

        .sidebar h2 {
            color: white;
            text-align: center;
        }

        .sidebar ul {
            list-style-type: none;
            padding: 0;
        }

        .sidebar li {
            margin-bottom: 10px;
            text-align: center;
        }

        .sidebar a {
            display: block;
            text-decoration: none;
            color: white;
            padding: 10px;
            transition: background-color 0.3s;
        }

        .sidebar a:hover {
            background-color: #555;
        }

        /* Styling for the content area (same as the dashboard) */
        .content {
            margin-left: 250px;
            padding: 20px;
        }

        .content h1 {
            font-size: 36px;
            margin-bottom: 20px;
        }

        /* Improved styling for the patient details form */
        .patient-details-form {
            background-color: #f7f7f7;
            border: 1px solid #ccc;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .patient-details-form h2 {
            font-size: 24px;
            margin-bottom: 10px;
        }

        .patient-details-form p {
            font-size: 16px;
            margin-bottom: 10px;
        }

        .form-input {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .form-button {
            background-color: #333;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .form-button:hover {
            background-color: #555;
        }

        /* Style for the Accept button with ID 'accept' */
        #accept {
            background-color: #4CAF50; /* Green color for accept */
            color: white;
            padding: 10px 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        #accept:hover {
            background-color: #45a049; /* Darker green on hover for accept */
        }

        /* Style for the Reject button with ID 'reject' */
        #reject {
            background-color: #f44336; /* Red color for reject */
            color: white;
            padding: 10px 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        #reject:hover {
            background-color: #d32f2f; /* Darker red on hover for reject */
        }
        /* Styles for centering the table */

    </style>
</head>
<body>
    <div class="sidebar">
        <h2>Dashboard</h2>
        <ul>
            <li><a href="#">Home</a></li>
            <li><a href="receptionist_process.php">Appointments</a></li>
            <li><a href="Dentist_Availability.php">Dentist Availability</a></li>
            <li><a href="Recep_Manager.php">Patients</a></li>
            <li><a href="Receptionist_Settings.php">Settings</a></li>
            <li><a href="Manage_Payments.php">Manage Payments</a></li>
            <li><a href="Completed.php">Completed Appointments</a></li>
            <li><a href="Main.php">Logout</a></li>
        </ul>
    </div>
<h1>Appointments to Review (Pending)</h1>
<table border="1">
    <tr>
        <th>Appointment ID</th>
        <th>Patient ID</th>
        <th>Appointment Date</th>
        <th>Appointment Time</th>
        <th>Treatment Name</th>
        <th>Treatment Description</th>
        <th>Status</th>
        <th>Action</th>
    </tr>
    <?php
    while ($row = mysqli_fetch_assoc($result_pending_canceled)) {
        echo "<tr>";
        echo "<td>" . $row['Appointment_ID'] . "</td>";
        echo "<td>" . $row['Patient_ID'] . "</td>";
        echo "<td>" . $row['Date'] . "</td>";
        echo "<td>" . $row['Time'] . "</td>";
        echo "<td>" . $row['Treatment_Name'] . "</td>";
        echo "<td>" . $row['Treatment_Desc'] . "</td>";
        echo "<td>" . $row['Status'] . "</td>";
        echo "<td>
            <form method='post'>
                <input type='hidden' name='appointment_id' value='" . $row['Appointment_ID'] . "'>
                <input type='submit' name='accept' value='Accept' id='accept'>
                <input type='submit' name='reject' value='Reject' id='reject'>

            </form>
            </td>";
        echo "</tr>";
    }
    ?>
</table>
<br>
<br>
<br>
<h1>Scheduled Appointments</h1>
<table border="1">
    <tr>
        <th>Appointment ID</th>
        <th>Dentist ID</th>
        <th>Patient ID</th>
        <th>Patient Name</th>
        <th>Appointment Date</th>
        <th>Appointment Time</th>
        <th>Treatment Name</th>
        <th>Treatment Description</th>
        <th>Dentist Name</th>
        <th>Status</th>
    </tr>
    <?php
    while ($row = mysqli_fetch_assoc($result_scheduled)) {
        echo "<tr>";
        echo "<td>" . $row['Appointment_ID'] . "</td>";
        echo "<td>" . $row['Dentist_ID'] . "</td>";
        echo "<td>" . $row['Patient_ID'] . "</td>";
        echo "<td>" . $row['Patient_Name'] . "</td>";
        echo "<td>" . $row['Date'] . "</td>";
        echo "<td>" . $row['Time'] . "</td>";
        echo "<td>" . $row['Treatment_Name'] . "</td>";
        echo "<td>" . $row['Treatment_Desc'] . "</td>";
        echo "<td>" . $row['Dentist_Name'] . "</td>";
        echo "<td>" . $row['Status'] . "</td>";
        echo "</tr>";
    }
    ?>
</table>
<br>
<br>
<br>
<h1>Canceled Appointments</h1>
<table border="1">
    <tr>
        <th>Appointment ID</th>
        <th>Patient ID</th>
        <th>Appointment Date</th>
        <th>Appointment Time</th>
        <th>Treatment Name</th>
        <th>Treatment Description</th>
        <th>Status</th>
    </tr>
    <?php
    mysqli_data_seek($result_pending_canceled, 0); // Reset the result pointer
    while ($row = mysqli_fetch_assoc($result_canceled)) {
        if ($row['Status'] == 'Canceled') {
            echo "<tr>";
            echo "<td>" . $row['Appointment_ID'] . "</td>";
            echo "<td>" . $row['Patient_ID'] . "</td>";
            echo "<td>" . $row['Date'] . "</td>";
            echo "<td>" . $row['Time'] . "</td>";
            echo "<td>" . $row['Treatment_Name'] . "</td>";
            echo "<td>" . $row['Treatment_Desc'] . "</td>";
            echo "<td>" . $row['Status'] . "</td>";
            echo "</tr>";
        }
    }
    ?>
</table>
<br>
<br>
<br>
<h1>Completed Treatments</h1>
<table border="1">
    <tr>
        <th>Appointment ID</th>
        <th>Patient ID</th>
        <th>Appointment Date</th>
        <th>Appointment Time</th>
        <th>Treatment Name</th>
        <th>Treatment Description</th>
        <th>Status</th>
    </tr>
    <?php
    while ($row = mysqli_fetch_assoc($result_completed)) {
        echo "<tr>";
        echo "<td>" . $row['Appointment_ID'] . "</td>";
        echo "<td>" . $row['Patient_ID'] . "</td>";
        echo "<td>" . $row['Date'] . "</td>";
        echo "<td>" . $row['Time'] . "</td>";
        echo "<td>" . $row['Treatment_Name'] . "</td>";
        echo "<td>" . $row['Treatment_Desc'] . "</td>";
        echo "<td>" . $row['Status'] . "</td>";
        echo "</tr>";
    }
    ?>
</table>
<!-- The rest of your HTML content -->
</body>
</html>
