<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bracewell Clinic</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<script>
    $(document).ready(function() {
        $("a.zoom-effect").click(function(event) {
            event.preventDefault(); // Prevent the default link behavior

            // Store the URL of the clicked link
            var link = $(this).attr("href");

            // Apply a zoom-out effect to the body
            $("body").animate({
                transform: "scale(0.5)",
                opacity: 0,
            }, 500, function() {
                // Redirect to the clicked link once the animation is complete
                window.location.href = link;
            });
        });
    });
</script>

    
    
    <style>
        
        .container {
        width: 80%; /* Adjust the width as needed */
        margin: 0 auto; /* Center the container */
    }

    /* Adjust padding for header */
    .header {
        padding: 100px 0;
        text-align: center;
        color: white;
        background-image: url("https://si-prod-cms-static-pz.b-cdn.net/thumbs/gumdisease_1280.jpg?v=201804115");
        background-size: cover;
        background-attachment: fixed;
        background-position: center top;
    }

    /* Adjust padding for sections */
    .doctors,
    .steps,
    .treatments,
    .patient-stories,
    .patient-feedback {
        padding: 30px 0; /* You can adjust the values as needed */
    }

    /* Adjust padding for footer */
    .footer {
        background-color: #333;
        color: white;
        text-align: center;
        padding: 20px 0;
    }
        /* Custom Styles */
        .navbar {
        position: fixed;
        top: 0;
        width: 100%;
        z-index: 1000;
    }

    .navbar-nav > li > a:hover {
        background-color: #555;
    }

    /* Header */
    .header {
        text-align: center;
        padding: 150px 0;
        color: white;
    }

    .header a {
        font-size: 20px;
        color: #333;
        text-decoration: none;
        border: 2px solid #333;
        padding: 10px 20px;
        border-radius: 5px;
        transition: background-color 0.3s;
    }

    .header a:hover {
        background-color: #555;
    }
        .navbar {
            margin-bottom: 0;
            border-radius: 0;
        }

        .navbar-inverse {
            background-color: #333;
            border-color: transparent;
        }

        .navbar-brand {
            font-size: 28px;
            color: #333;
        }

        .navbar-nav > li > a {
            font-size: 18px;
            color: #333;
        }

        .header {
            padding: 100px 0;
            text-align: center;
            color: white;
            background-image: url("https://si-prod-cms-static-pz.b-cdn.net/thumbs/gumdisease_1280.jpg?v=201804115");
            background-size: cover;
            background-attachment: fixed;
            background-position: center top;
        }

        .header h2 {
            font-size: 40px;
            margin-bottom: 20px;
        }

        .doctors {
            padding: 50px;
        }

        .doctors h2 {
            font-size: 28px;
            color: #333;
        }

        .doctor {
            margin-bottom: 30px;
            padding: 20px;
            transition: transform 0.3s ease-in-out;
            text-align: center;
            cursor: pointer; /* Add a cursor pointer to indicate these are clickable */
        }

        /* Background color for odd doctors */
        .doctor:nth-child(odd) {
            background-color: #E0E0E0;
        }

        /* Background color for even doctors */
        .doctor:nth-child(even) {
            background-color: #FFFFFF;
        }

        
        .doctor:hover {
            transform: scale(1.05);
            background-color: #99ccff;
        }
        

        .doctor img {
            width: 150px; /* Set a fixed width */
            height: 150px; /* Set a fixed height */
            object-fit: cover; /* Maintain aspect ratio while covering the container */
            border-radius: 50%;
        }

        .doctor h3 {
            font-size: 24px;
            color: #333;
        }

        .doctor p {
            font-size: 16px;
            color: #666;
        }

        .steps {
            background-color: rgba(0, 0, 0, 0.5);
            color: white;
            padding: 50px;
            text-align: center;
        }

        .steps h2 {
            font-size: 36px;
        }

        .patient-stories {
            padding: 50px;
        }

        .patient-story {
            margin-bottom: 30px;
        }

        .patient-story img {
            max-width: 100%;
            border-radius: 5px;
        }

        .patient-story h3 {
            font-size: 24px;
            color: #333;
        }

        .patient-story p {
            font-size: 16px;
            color: #666;
        }

        .patient-feedback {
            background-color: #E0E0E0;
            padding: 20px;
            border-radius: 10px;
            transition: transform 0.3s ease-in-out;
        }

        .patient-feedback:hover {
            transform: scale(1.05);
        }

        /* Footer */
        .footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 20px;
        }
        
        /* Treatments */
.treatments {
    padding: 50px;
}

/* Treatments */
.treatments {
    padding: 50px;
}

.treatment {
    margin-bottom: 30px;
    padding: 20px;
    text-align: center;
    cursor: pointer;
    background-color: #E0E0E0;
    height: 100%; /* Set a fixed height for the cards */
    transition: transform 0.3s ease-in-out;
}

.treatment:hover {
    transform: scale(1.05);
    background-color: #99ccff;
}

.treatment img {
    width: 150px;
    height: 150px;
    object-fit: cover;
    border-radius: 50%;
}

.treatment h3 {
    font-size: 24px;
    color: #333;
}

.treatment p {
    font-size: 16px;
    color: #666;
}


    </style>
</head>
<body>
<nav class="navbar navbar-inverse">
        <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand" href="#">Bracewell Clinic</a>
            </div>
            <ul class="nav navbar-nav">
                <li class="active"><a href="#">Home</a></li>
                <li><a href="#about">About us</a></li>
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">Treatments <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="Treatments.php">Dental Cleaning</a></li>
                        <li><a href="Treatments.php">Tooth Extraction</a></li>
                        <li><a href="Treatments.php">Dental Implant Surgery</a></li>
                        <li><a href="Treatments.php">Root Canal Therapy</a></li>
                    </ul>
                </li>
                <li><a href="Products.php">Products</a></li>
                <li><a href="DentalHealthResources.php">Resources</a></li>
                <li><a href="new_reg.php">Register now</a></li>
               <li><a href="Login.php">Login</a></li>
               <li><a href="#about">Contact us</a></li>
            </ul>
        </div>
    </nav>


    <div class="header">
        <h2>Dental Clinic</h2>
        <h2>Management System</h2>
    </div>

 
    <div class="container doctors">
        <h2>Meet Our Doctors</h2>
        <div class="row">
            <div class="col-md-4">
                <a href="Dentists.php"> 
                    <div class="doctor">
                        <img src="https://cdn1.edgedatg.com/aws/v2/abc/TheGoodDoctor/person/2057161/3b64a2c60ab1522e01e641c6231ced0a/512x288-Q90_3b64a2c60ab1522e01e641c6231ced0a.jpg" alt="Doctor 1">
                        <h3>Dr. John Smith</h3>
                        <p>Specialty: Dentistry</p>
                        <p>Dr. John Doe is a highly experienced dentist specializing in general dentistry. He has been serving patients for over 20 years and is known for his gentle and caring approach.</p>
                    </div>
                </a>
            </div>
            <div class="col-md-4">
                <a href="Dentists.php"> <!-- Link to Dentists.php -->
                    <div class="doctor">
                        <img src="https://www.dgepress.com/storage/uploads/D7/A4/D7A472E6-7EA3-C5EE-CCFE-2FA4E8264665/152740_2772_V9-0x300.jpg" alt="Doctor 2">
                        <h3>Dr. Sarah Johnsonh</h3>
                        <p>Specialty: Orthodontics</p>
                        <p>Dr. Jane Smith is a skilled orthodontist with a passion for creating beautiful smiles. She uses the latest techniques in orthodontics to provide the best possible care to her patients.</p>
                    </div>
                </a>
            </div>
            <div class="col-md-4">
                <a href="Dentists.php">
                    <div class="doctor">
                        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQQ0dcbZvwN6dJUCpgN-4BeFEpEiTcjY5SOtw&usqp=CAU" alt="Doctor 3">
                        <h3>Dr. Michael Lee</h3>
                        <p>Specialty: Oral Surgery</p>
                        <p>Dr. James Brown is an experienced oral surgeon known for his precision and expertise in surgical procedures. He is dedicated to ensuring the comfort and safety of his patients.</p>
                    </div>
                </a>
            </div>
        </div>
    </div>
    
    <div class="steps" style="background-image: url('https://si-prod-cms-static-pz.b-cdn.net/thumbs/gumdisease_1280.jpg?v=201804115'); background-size: cover; background-attachment: fixed;">
    <h2>Welcome to Our Clinic</h2>
    <p>Welcome to Bracewell Clinic, where we are dedicated to providing the highest quality dental care to our patients. Our team of experienced dentists and staff is committed to ensuring your oral health and creating beautiful smiles.</p>
</div>
    
<div class="container treatments">
    <h2>Our Treatments</h2>
    <div class="row">
        <div class="col-md-4">
            <a href="Treatments.php">
                <div class="treatment">
                    <img src="dental_checkup.jpg" alt="Treatment 1">
                    <h3>Dental Cleaning</h3>
                    <p>Regular dental cleanings are essential for maintaining oral health and preventing dental issues.Our professional cleaning services will leave your teeth clean.</p>
                </div>
            </a>
        </div>
        <div class="col-md-4">
            <a href="Treatments.php">
                <div class="treatment">
                    <img src="tooth_cleaning.jpg" alt="Treatment 2">
                    <h3>Teeth Whitening</h3>
                    <p>Get a brighter, whiter smile with our teeth whitening treatments. We offer both in-office and take-home options for your convenience.</p>
                </div>
            </a>
        </div>
        <div class="col-md-4">
            <a href="Treatments.php">
                <div class="treatment">
                    <img src="tooth_removal.jpg" alt="Treatment 3">
                    <h3>Dental Implants</h3>
                    <p>Missing teeth? Dental implants provide a permanent solution to restore your smile's functionality and aesthetics. Consult with our experts for the best implant options.</p>
                </div>
            </a>
        </div>
    </div>
</div>
    




    <div class="steps" style="background-image: url('https://si-prod-cms-static-pz.b-cdn.net/thumbs/gumdisease_1280.jpg?v=201804115'); background-size: cover; background-attachment: fixed;">
        <h2>3 SIMPLE STEPS FOR ACHIEVING YOUR BEST SMILE</h2>
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h3>Step 1</h3>
                    <p>Consult with our experienced dentists to discuss your dental goals and concerns.</p>
                </div>
                <div class="col-md-4">
                    <h3>Step 2</h3>
                    <p>Receive personalized treatment plans and options tailored to your needs.</p>
                </div>
                <div class="col-md-4">
                    <h3>Step 3</h3>
                    <p>Experience top-quality dental care and achieve your best smile with us.</p>
                </div>
            </div>
        </div>
    </div>


    <div class="container patient-stories">
        <h2>Patient Stories</h2>
        <div class="row">
            <div class="col-md-6">
                <div class="patient-story">
                   
                    <h3>John's Story</h3>
                    <p>John had been struggling with dental issues for years. He visited Bracewell Clinic, and Dr. Doe's expertise and caring approach made all the difference. John now enjoys a healthy and confident smile.</p>
                </div>
            </div>
            <div class="col-md-6">
                <div class="patient-story">
                    
                    <h3>Jane's Story</h3>
                    <p>Jane's journey to a perfect smile started with a visit to Bracewell Clinic. Dr. Smith's orthodontic skills and dedication exceeded her expectations. She can't stop smiling!</p>
                </div>
            </div>
        </div>
    </div>


    <div class="container patient-feedback">
        <h2>Patient Feedback</h2>
        <div class="row">
            <div class="col-md-6">
                <div class="patient-feedback">
                    <h3>Feedback from John</h3>
                    <p>"I had a fantastic experience at Bracewell Clinic. The staff is friendly, and Dr. Doe did an excellent job with my dental work. I highly recommend them!"</p>
                </div>
            </div>
            <div class="col-md-6">
                <div class="patient-feedback">
                    <h3>Feedback from Jane</h3>
                    <p>"Bracewell Clinic is amazing! Dr. Smith is incredibly skilled, and the results of my orthodontic treatment exceeded my expectations."</p>
                </div>
            </div>
        </div>
    </div>

  
    <footer class="footer">
        <div class="container" id="about">
            <p>About Us: We are dedicated to providing the highest quality dental care to our patients.</p>
            <p>Contact: Test@bracewellclinic.com</p>
            <p>Address: 123 Dental Street, Cityville, ZIP</p>
            <p>&copy; 2023 Bracewell Clinic</p>
        </div>
    </footer>
    <script>
  $(document).ready(function() {
    // Function to animate elements when they come into view
    function animateOnScroll(element, animationClass) {
      var offset = $(element).offset().top - window.innerHeight + 100;

      function addAnimationClass() {
        $(element).addClass('animated ' + animationClass);
      }

      // Trigger the animation when the element is in view
      $(window).scroll(function() {
        if ($(window).scrollTop() > offset) {
          addAnimationClass();
        }
      });

      // Trigger the animation if the element is already in view on page load
      if ($(window).scrollTop() > offset) {
        addAnimationClass();
      }
    }

    // Apply animations to meet our doctors section
    animateOnScroll('.doctors', 'fadeInUp');

    // Apply animations to welcome to our clinic section
    animateOnScroll('.steps', 'fadeInLeft');

    // Apply animations to 3 simple steps section
    animateOnScroll('.steps', 'fadeInRight');
  });
</script>

</body>
</html>