<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedbacks</title>
    <style>
        /* Add your CSS styles for the Feedbacks page here */
        body {
            font-family: Arial, sans-serif;
        }

        h1 {
            color: #007BFF;
            text-align: center;
            margin-top: 20px;
        }

        .container {
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
        }

        .feedback-card {
            margin: 20px 0;
            padding: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.1);
        }

        .btn-container {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }

        .home-btn {
            background-color: #007BFF;
            color: white;
            border: none;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .home-btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <br>
    <a class="home-btn" href="admin.php">Back to Admin</a>
    <h1>Feedbacks</h1>

    <div class="container">
        <?php
        // Database connection (replace with your actual connection code)
        $host = "localhost";
        $dbUsername = "root";
        $dbPassword = "";
        $dbname = "dbclinicmain";
        $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);

        // Check if the connection was successful
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Fetch and display feedbacks
        $sql = "SELECT * FROM Tbl_Feedback";
        $result = $conn->query($sql);

        if ($result !== false && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo '<div class="feedback-card">';
                echo '<p><strong>Feedback ID:</strong> ' . htmlspecialchars($row["Feedback_ID"]) . '</p>';
                echo '<p><strong>Patient ID:</strong> ' . htmlspecialchars($row["Patient_ID"]) . '</p>';
                echo '<p><strong>Comment:</strong> ' . htmlspecialchars($row["Comment"]) . '</p>';
                echo '<p><strong>Date:</strong> ' . htmlspecialchars($row["Date"]) . '</p>';
                echo '</div>';
            }
        } else {
            echo '<p>No feedbacks available.</p>';
        }

        // Close the database connection
        $conn->close();
        ?>
    </div>
</body>
</html>
