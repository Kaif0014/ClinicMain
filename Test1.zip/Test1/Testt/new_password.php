<?php
// Retrieve the email from the cookie
if (isset($_COOKIE['email'])) {
    $email = $_COOKIE['email'];

    // Now, you can use the $email variable as needed in this page
    
} else {
    // Handle the case when the email is not available in the cookie
    echo "Email not provided.";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Password Update</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        /* Custom Styles */
        body {
            background-color: #f5f5f5;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .navbar {
            background-color: #007BFF;
            color: #fff;
        }

        .navbar-brand {
            font-size: 24px;
            color: #fff;
        }

        .container {
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            padding: 20px;
            margin: 20px auto;
            max-width: 400px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            font-weight: bold;
        }

        .form-control {
            border: 2px solid #007BFF;
            border-radius: 5px;
        }

        .btn {
            background-color: #007BFF;
            color: #fff;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            cursor: pointer;
        }

        .btn:hover {
            background-color: #0056b3;
        }

        .remember-me {
            margin-top: 10px;
        }

        /* Add some space below the Register button for the "Already have an account?" link */
        .already-have-account {
            margin-top: 20px;
        }
    </style>
</head>
<body>
<nav class="navbar">
    <div class="container-fluid">
        <a class="navbar-brand" href="Main.php">Bracewell Clinic</a>
    </div>
</nav>

<div class="container">
    <h2 class="mt-4">Change Password</h2>
    <form action="new_password.php" method="post">
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="text" class="form-control" id="email" name="email" value="<?php echo isset($_COOKIE['email']) ? $_COOKIE['email'] : ''; ?>" readonly>
        </div>

        <div class="form-group">
            <label for="password">New Password:</label>
            <input type="password" class="form-control" name="password" id="password" required>
        </div>

        <div class="form-group">
            <button type="submit" class="btn">Change</button>
        </div>
    </form>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
<?php
if (isset($_POST['email']) && isset($_POST['password'])) {
    $host = "localhost";
    $username = "root";
    $password = "";
    $database = "dbclinicmain";

    // Create a database connection
    $conn = new mysqli($host, $username, $password, $database);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $email = $_POST['email'];
    $new_password = $_POST['password'];

    // Check if the email exists in the 'patient' table
    $check_sql = "SELECT * FROM tbl_patient WHERE Email = '$email'";
    $result = $conn->query($check_sql);

    if ($result->num_rows > 0) {
        // Email exists, update the password
        $update_sql = "UPDATE tbl_patient SET Password = '$new_password' WHERE Email = '$email'";
        
        if ($conn->query($update_sql) === TRUE) {
            // Password updated successfully
            echo "<script>alert('Password updated successfully!'); window.location.href = 'Login.php';</script>";
        } else {
            echo "Error: " . $conn->error;
        }
    } else {
        // Email not registered
        echo "<script>alert('Email is not registered. Please register first.'); window.location.href = 'Main.php';</script>";
    }

    // Close the database connection
    $conn->close();
}
?>
