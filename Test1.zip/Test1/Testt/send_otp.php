<?php
session_start();
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
    
require 'vendor/autoload.php';
    
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dbclinicmain";

// Create a connection to the database
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
setcookie('email', $_POST['email'], time() + 3600); // Cookie valid for 1 hour

// Get the email from the form
$email = $_POST['email'];
// Query to check if the email already exists in the "patient" table
    $sql = "SELECT Email FROM tbl_patient WHERE email = '$email'
UNION
SELECT Email FROM tbl_dentist WHERE email = '$email'
UNION
SELECT Email FROM tbl_receptionist WHERE email = '$email';
";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
        echo '<script>alert("Email is already registered.");</script>';
        echo '<script>window.location.href="new_reg.php";</script>';
        exit; 
} else {
    // Generate a random OTP
    $otp = mt_rand(100000, 999999);
    
    // Get the user's email from the registration form
    $email = $_POST['email'];
    
    // Store the OTP in a session variable
    
    $_SESSION['otp'] = $otp;
    // Create a new PHPMailer instance
    $mail = new PHPMailer();
    
    // Set up the SMTP server settings
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'ogasiagame@gmail.com'; // Your Gmail email
    $mail->Password = 'flqvkyxfvuefsgnz'; // Your Gmail password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;
    
    // Sender and recipient information
    $mail->setFrom('ogasiagame@gmail.com', 'Bracewell Clinic');
    $mail->addAddress($email);
    
    // Email subject and bodys
    $mail->isHTML(true);
    $mail->Subject = 'OTP Verification';
    $mail->Body = 'Your OTP for registration: ' . $otp;
    
    
    
    // Send the email
    if ($mail->send()) {
        echo 'An OTP has been sent to your email. Please check your email for verification.';
    } else {
        echo 'Email could not be sent. Please try again later.';
    }
    header('Location:Verify.php');
    exit();
}


?>
