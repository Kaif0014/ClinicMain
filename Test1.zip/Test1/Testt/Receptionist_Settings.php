<?php
session_start(); // Start or resume a session

$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "dbclinicmain";

// Create a database connection
$conn = mysqli_connect($host, $dbUsername, $dbPassword, $dbname);

// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Initialize variables for receptionist details
$recepID = "";
$recepName = "";
$recepGender = "";
$recepAddress = "";
$recepEmail = "";
$recepContactNo = "";
$recepPassword = "";

if (isset($_SESSION['receptionist_email'])) {
    $recepEmail = $_SESSION['receptionist_email'];

    // Fetch receptionist details based on the user's email
    $sql = "SELECT * FROM tbl_receptionist WHERE Email = '$recepEmail'";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        if (mysqli_num_rows($result) > 0) {
            // Receptionist found, get their details
            $row = mysqli_fetch_assoc($result);
            $recepID = htmlspecialchars($row["Receptionist_ID"]);
            $recepName = htmlspecialchars($row["Receptionist_Name"]);
            $recepGender = htmlspecialchars($row["Gender"]);
            $recepAddress = htmlspecialchars($row["Address"]);
            $recepContactNo = htmlspecialchars($row["Contact_No"]);
            $recepPassword = htmlspecialchars($row["Password"]);
        } else {
            echo "<p>No receptionist found with the provided email.</p>";
        }
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}

// Handle updating the receptionist profile
// Handle updating the receptionist profile
if (isset($_POST['update_profile'])) {
    $newName = mysqli_real_escape_string($conn, $_POST['new_name']);
    $newAddress = mysqli_real_escape_string($conn, $_POST['new_address']);
    $newEmail = mysqli_real_escape_string($conn, $_POST['new_email']);
    $newContactNo = mysqli_real_escape_string($conn, $_POST['new_contact_no']);
    $newPassword = mysqli_real_escape_string($conn, $_POST['new_password']);
    $currentPassword = mysqli_real_escape_string($conn, $_POST['current_password']);

    // Check if the current password matches the one in the database
    if ($currentPassword === $recepPassword) {
        // Update the receptionist's profile with plain text password
        $updateSql = "UPDATE tbl_receptionist
                     SET Receptionist_Name = '$newName', 
                         Address = '$newAddress', 
                         Email = '$newEmail', 
                         Contact_No = '$newContactNo', 
                         Password = '$newPassword'
                     WHERE Receptionist_ID = $recepID";

         if (mysqli_query($conn, $updateSql)) {
            echo '<script>alert("Profile updated successfully.");</script>';
        } else {
            echo '<script>alert("Error updating profile: ' . mysqli_error($conn) . '");</script>';
        }
    } else {
        echo '<script>alert("Current password is incorrect. Profile not updated.");</script>';
    }
}


// Close the database connection
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receptionist Settings</title>
    <style>
        /* Reset some default styles */
        body, h1, h2, p, ul, li {
            margin: 0;
            padding: 0;
        }

        /* Improved styling for the navbar */
        .navbar {
            background-color: #ffc107;
            color: #fff;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
        }

        .navbar-brand {
            font-size: 24px;
            color: #fff;
        }

        .navbar-right {
            display: flex;
            align-items: center;
        }

        .recep-welcome {
            color: #fff;
            margin-right: 10px;
        }

        .welcome-icon {
            color: #fff;
            font-size: 24px;
        }

        /* Improved styling for the sidebar */
        .sidebar {
            height: 100%;
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #333;
            padding-top: 20px;
            transition: width 0.3s;
        }

        .sidebar h2 {
            color: white;
            text-align: center;
        }

        .sidebar ul {
            list-style-type: none;
            padding: 0;
        }

        .sidebar li {
            margin-bottom: 10px;
            text-align: center;
        }

        .sidebar a {
            display: block;
            text-decoration: none;
            color: white;
            padding: 10px;
            transition: background-color 0.3s;
        }

        .sidebar a:hover {
            background-color: #555;
        }

        /* Styling for the content area */
        .content {
            margin-left: 250px;
            padding: 20px;
        }

        .content h1 {
            font-size: 36px;
            margin-bottom: 20px;
        }

        /* Attractive content styling */
        .welcome-section {
            background-color: #f7f7f7;
            border: 1px solid #ccc;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .welcome-section h2 {
            font-size: 24px;
            margin-bottom: 10px;
            color: #333;
        }

        .welcome-section p {
            font-size: 16px;
            margin-bottom: 10px;
            color: #555;
        }

        /* Form styling */
        form {
            background-color: #f7f7f7;
            border: 1px solid #ccc;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        form label {
            font-size: 16px;
        }

        form input {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        form button {
            background-color: #ffc107;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        /* Responsive design for smaller screens */
        @media screen and (max-width: 768px) {
            .sidebar {
                width: 100px;
            }

            .content {
                margin-left: 100px;
            }

            .sidebar h2 {
                font-size: 20px;
            }

            .sidebar ul {
                padding-left: 20px;
            }

            .sidebar li {
                margin-bottom: 5px;
            }

            .sidebar a {
                padding: 5px;
            }

            .content h1 {
                font-size: 24px;
            }

            form label {
                font-size: 14px;
            }

            form input {
                padding: 8px;
                margin-bottom: 8px;
            }

            form button {
                padding: 8px 16px;
            }
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar">
        <div class="navbar-left">
            <a class="navbar-brand" href="#">Bracewell Clinic</a>
        </div>
        <div class="navbar-right">
            <span class="recep-welcome">Welcome, <?php echo $recepName; ?></span>
            <i class="welcome-icon fas fa-user"></i>
        </div>
    </nav>

    <!-- Your HTML code for the dashboard -->
  <div class="sidebar">
        <h2>Dashboard</h2>
        <ul>
            <li><a href="#">Home</a></li>
            <li><a href="receptionist_process.php">Appointments</a></li>
            <li><a href="Dentist_Availability.php">Dentist Availability</a></li>
            <li><a href="Recep_Manager.php">Patients</a></li>
            <li><a href="Receptionist_Settings.php">Settings</a></li>
            <li><a href="Manage_Payments.php">Manage Payments</a></li>
            <li><a href="Completed.php">Completed Appointments</a></li>
            <li><a href="Main.php">Logout</a></li>
        </ul>
    </div>
    
    <div class="content">
        <h1>Welcome, <?php echo $recepName; ?>!</h1>
        <div class="welcome-section">
            <h2>Your Receptionist Dashboard</h2>
            <p>Welcome to your receptionist dashboard. You can manage appointments, view patient records, and configure settings from the sidebar navigation.</p>
        </div>
        <!-- Include the form for updating the receptionist's profile -->
        <form method="POST">
            <h2>Update Your Profile</h2>
            <label for="new_name">Name:</label>
            <input type="text" id="new_name" name="new_name" value="<?php echo $recepName; ?>" required><br>

            <label for="new_address">Address:</label>
            <input type="text" id="new_address" name="new_address" value="<?php echo $recepAddress; ?>" required><br>

            <label for="new_email">Email:</label>
            <input type="email" id="new_email" name="new_email" value="<?php echo $recepEmail; ?>" required><br>

            <label for="new_contact_no">Contact No:</label>
            <input type="text" id="new_contact_no" name="new_contact_no" value="<?php echo $recepContactNo; ?>" required><br>

            <label for="current_password">Current Password:</label>
            <input type="password" id="current_password" name="current_password" required><br>

            <label for="new_password">New Password:</label>
            <input type="password" id="new_password" name="new_password" required><br>

            <button type="submit" name="update_profile">Update Profile</button>
        </form>
    </div>
</body>
</html>
