<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Statistics</title>
    <style>
        /* Add your CSS styles for the statistics page here */
        /* You can customize the styling as needed */
        body {
            font-family: Arial, sans-serif;
        }

        .container {
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
        }

        h2 {
            color: #007BFF;
            text-align: center;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #007BFF;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        /* Add additional CSS styles for your charts here */
        .chart-container {
            margin: 20px auto;
        }
       .home-btn {
            background-color: #007BFF;
            color: white;
            border: none;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .home-btn:hover {
            background-color: #0056b3;
        }
    </style>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <br>
    <a class="home-btn" href="admin.php">Back to Admin</a>
    
    <h2>Monthly and Daily Income Statistics</h2>
    <div class="container">
        <h3>Monthly Income</h3>
        <table>
            <tr>
                <th>Month</th>
                <th>Total Income</th>
            </tr>
            <!-- Fetch and display monthly income statistics from the database -->
            <?php
            $host = "localhost";
            $dbUsername = "root";
            $dbPassword = "";
            $dbname = "dbclinicmain";
            $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);

            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            $sql = "SELECT DATE_FORMAT(Date, '%Y-%m') AS Month, SUM(Cost) AS TotalIncome
                    FROM tbl_appointment AS a
                    INNER JOIN Tbl_Treatment AS t ON a.Treatment_ID = t.Treatment_ID
                    WHERE a.Status = 'Completed'
                    GROUP BY Month";
            $result = $conn->query($sql);

            if ($result !== false && $result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row["Month"]) . "</td>";
                    echo "<td>" . htmlspecialchars($row["TotalIncome"]) . " Rs</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='2'>No monthly income data available.</td></tr>";
            }

            $conn->close();
            ?>
        </table>
    </div>

    <div class="container chart-container">
        <h3>Monthly Income Chart</h3>
        <canvas id="monthlyIncomeChart"></canvas>
    </div>

    <!-- Add a chart container for the daily income line chart -->
    <div class="container chart-container">
        <h3>Daily Income Chart</h3>
        <canvas id="dailyIncomeChart"></canvas>
    </div>
    

    <!-- JavaScript for chart rendering -->
    <script>
        // Fetch data for monthly income chart from PHP
        <?php
        $monthlyData = [];
        $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $sql = "SELECT DATE_FORMAT(Date, '%Y-%m') AS Month, SUM(Cost) AS TotalIncome
                FROM tbl_appointment AS a
                INNER JOIN Tbl_Treatment AS t ON a.Treatment_ID = t.Treatment_ID
                WHERE a.Status = 'Completed'
                GROUP BY Month";
        $result = $conn->query($sql);

        if ($result !== false && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $monthlyData[] = [
                    "month" => $row["Month"],
                    "income" => $row["TotalIncome"],
                ];
            }
        }

        $conn->close();
        ?>

        // Fetch data for daily income chart from PHP
        <?php
        $dailyData = [];
        $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $sql = "SELECT Date, SUM(Cost) AS TotalIncome
                FROM tbl_appointment AS a
                INNER JOIN Tbl_Treatment AS t ON a.Treatment_ID = t.Treatment_ID
                WHERE a.Status = 'Completed'
                GROUP BY Date";
        $result = $conn->query($sql);

        if ($result !== false && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $dailyData[] = [
                    "date" => $row["Date"],
                    "income" => $row["TotalIncome"],
                ];
            }
        }

        $conn->close();
        ?>

        // JavaScript code to render monthly income chart
        var monthlyIncomeData = <?php echo json_encode($monthlyData); ?>;
        var monthlyIncomeChart = new Chart(document.getElementById('monthlyIncomeChart'), {
            type: 'line',
            data: {
                labels: monthlyIncomeData.map(item => item.month),
                datasets: [{
                    label: 'Monthly Income',
                    data: monthlyIncomeData.map(item => item.income),
                    borderColor: '#007BFF',
                    borderWidth: 2,
                    fill: false,
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        // JavaScript code to render daily income chart
        var dailyIncomeData = <?php echo json_encode($dailyData); ?>;
        var dailyIncomeChart = new Chart(document.getElementById('dailyIncomeChart'), {
            type: 'line',
            data: {
                labels: dailyIncomeData.map(item => item.date),
                datasets: [{
                    label: 'Daily Income',
                    data: dailyIncomeData.map(item => item.income),
                    borderColor: '#007BFF',
                    borderWidth: 2,
                    fill: false,
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
    <!-- End of JavaScript for chart rendering -->
</body>
</html>
