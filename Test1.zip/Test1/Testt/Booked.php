<?php
session_start(); // Start or resume a session

$userID = $_SESSION['userID'];
$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "DBClinicmain";

// Create a connection to the database
$conn = mysqli_connect($host, $dbUsername, $dbPassword, $dbname);

// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Fetch patient information
$patientInfoSQL = "SELECT Patient_Name, DOB, Gender, Email, Address
                  FROM tbl_patient
                  WHERE Patient_ID = '$userID'";
$patientInfoResult = mysqli_query($conn, $patientInfoSQL);

// Fetch treatment, dentist, and appointment information
$appointmentInfoSQL = "SELECT p.Patient_Name, p.DOB as Patient_DOB, p.Gender as Patient_Gender, p.Email as Patient_Email, p.Address as Patient_Address, 
                      t.Treatment_Name, t.Treatment_Desc, t.Cost, 
                      d.Dentist_Name, d.Gender as Dentist_Gender, d.Email as Dentist_Email, 
                      a.Date, a.Time, a.Status
                      FROM tbl_appointment a
                      INNER JOIN tbl_patient p ON a.Patient_ID = p.Patient_ID
                      INNER JOIN tbl_treatment t ON a.Treatment_ID = t.Treatment_ID
                      INNER JOIN tbl_dentist d ON t.Dentist_id = d.Dentist_id
                      WHERE a.Patient_ID = '$userID'
                      ORDER BY a.Appointment_ID DESC LIMIT 1";
$appointmentInfoResult = mysqli_query($conn, $appointmentInfoSQL);

if ($patientInfoResult && $appointmentInfoResult) {
    if (mysqli_num_rows($patientInfoResult) > 0 && mysqli_num_rows($appointmentInfoResult) > 0) {
        $patientInfo = mysqli_fetch_assoc($patientInfoResult);
        $appointmentInfo = mysqli_fetch_assoc($appointmentInfoResult);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booked Appointment</title>
    <style>
        /* Add the styles from your original code here */
        body {
            font-family: Arial, sans-serif;
            background-color: #f7f7f7;
            margin: 0;
            padding: 0;
        }

        .navbar {
            background-color: #333;
            overflow: hidden;
        }

        .navbar a {
            float: left;
            font-size: 16px;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        .navbar a:hover {
            background-color: #ddd;
            color: black;
        }

        .card {
            background-color: #ffffff;
            border: 1px solid #ccc;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin: 20px;
            padding: 20px;
        }

        h1 {
            font-size: 24px;
            margin-bottom: 20px;
        }

        h2 {
            font-size: 20px;
            margin-bottom: 10px;
        }

        p {
            font-size: 16px;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <a href="Browse_treatment.php">&#8592; Back</a>
    </div>
    <h1 align="center">Booked Appointment</h1>

    <!-- Patient Information Card -->
    <div class="card">
        <h2>Patient Information</h2>
        <p>Name: <?php echo $patientInfo['Patient_Name']; ?></p>
        <p>Date of Birth: <?php echo $patientInfo['DOB']; ?></p>
        <p>Gender: <?php echo $patientInfo['Gender']; ?></p>
        <p>Email: <?php echo $patientInfo['Email']; ?></p>
        <p>Address: <?php echo $patientInfo['Address']; ?></p>
    </div>

    <!-- Treatment Information Card -->
    <div class="card">
        <h2>Treatment Information</h2>
        <p>Treatment Name: <?php echo $appointmentInfo['Treatment_Name']; ?></p>
        <p>Description: <?php echo $appointmentInfo['Treatment_Desc']; ?></p>
        <p>Cost: <?php echo $appointmentInfo['Cost']; ?> Rs</p>
    </div>

    <!-- Dentist Information Card -->
    <div class="card">
        <h2>Dentist Information</h2>
        <p>Dentist Name: <?php echo $appointmentInfo['Dentist_Name']; ?></p>
        <p>Dentist Gender: <?php echo $appointmentInfo['Dentist_Gender']; ?></p>
        <p>Dentist Email: <?php echo $appointmentInfo['Dentist_Email']; ?></p>
    </div>

    <!-- Appointment Information Card -->
    <div class="card">
        <h2>Appointment Information</h2>
        <p>Date: <?php echo $appointmentInfo['Date']; ?></p>
        <p>Time: <?php echo $appointmentInfo['Time']; ?></p>
        <p>Status: <?php echo $appointmentInfo['Status']; ?></p>
    </div>
</body>
</html>
<?php
    } else {
        echo "<p>No appointment information found.</p>";
    }
} else {
    echo "Error: " . mysqli_error($conn);
}

// Close the database connection
mysqli_close($conn);
?>
