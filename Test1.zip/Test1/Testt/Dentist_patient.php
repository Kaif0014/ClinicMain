<?php
$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "dbclinicmain";

// Create a database connection
$conn = mysqli_connect($host, $dbUsername, $dbPassword, $dbname);

// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT * FROM tbl_patient";
$result = mysqli_query($conn, $sql);

if ($result) {
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $patients[] = $row;
        }
    } else {
        $patients = [];
    }
} else {
    echo "Error: " . mysqli_error($conn);
}

// Close the database connection
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Data</title>
    <style>
        /* Reset some default styles */
        body, h1, h2, p, ul, li {
            margin: 0;
            padding: 0;
        }

        /* Improved styling for the navbar */
        .navbar {
            background-color: #17a2b8;
            color: #fff;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
        }

        .navbar-brand {
            font-size: 24px;
            color: #fff;
        }

        .navbar-right {
            display: flex;
            align-items: center;
        }

        .dentist-welcome {
            color: #fff;
            margin-right: 10px;
        }

        .welcome-icon {
            color: #fff;
            font-size: 24px;
        }

        /* Improved styling for the sidebar */
        .sidebar {
            height: 100%;
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #333;
            padding-top: 20px;
            transition: width 0.3s;
        }

        .sidebar h2 {
            color: white;
            text-align: center;
        }

        .sidebar ul {
            list-style-type: none;
            padding: 0;
        }

        .sidebar li {
            margin-bottom: 10px;
            text-align: center;
        }

        .sidebar a {
            display: block;
            text-decoration: none;
            color: white;
            padding: 10px;
            transition: background-color 0.3s;
        }

        .sidebar a:hover {
            background-color: #555;
        }

        /* Styling for the content area */
        .content {
            margin-left: 250px;
            padding: 20px;
        }

        .content h1 {
            font-size: 36px;
            margin-bottom: 20px;
        }

        /* Attractive content styling */
        .patient-card {
            background-color: #f7f7f7;
            border: 1px solid #ccc;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        table {
            font-size: 18px;
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #f2f2f2;
        }

        /* Search and filter section styles */
        .search-filter-section {
            margin-bottom: 20px;
        }

        .search-filter-section select,
        .search-filter-section input[type="text"] {
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <!-- Navbar -->

    <!-- Your HTML code for the dashboard -->
    <div class="sidebar">
        <h2>Dashboard</h2>
        <ul>
            <li><a href="Dentist_Home.php">Home</a></li>
            <li><a href="Dentist_appointment.php">Appointments</a></li>
            <li><a href="Completed_Appointments.php">Completed Appointments</a></li>
            <li><a href="Dentist_patient.php">Patients</a></li>
            <li><a href="Dentist_Settings.php">Settings</a></li>
            <li><a href="Main.php">Logout</a></li>
        </ul>
    </div>
    <div class="content">
        <h1>Patients Data</h1>

        <!-- Search and filter section -->
        <div class="search-filter-section">
            <select id="filterCriteria">
                <option value="all">All</option>
                <option value="Patient_ID">Patient ID</option>
                <option value="Patient_Name">Patient Name</option>
                <option value="DOB">Date of Birth</option>
                <option value="Address">Address</option>
                <option value="Email">Email</option>
                <option value="Contact_Number">Contact Number</option>
            </select>
            <input type="text" id="filterValue" placeholder="Enter value to filter">
        </div>

        <div class="welcome-section">
            <?php if (!empty($patients)) { ?>
                <?php foreach ($patients as $patient) { ?>
                   <div class="patient-card">
    <p class="Patient_ID"><strong>Patient ID:</strong> <?php echo $patient['Patient_ID']; ?></p>
    <p class="Email"><strong>Email:</strong> <?php echo $patient['Email']; ?></p>
    <p class="Patient_Name"><strong>Patient Name:</strong> <?php echo $patient['Patient_Name']; ?></p>
    <p class="DOB"><strong>Date of Birth:</strong> <?php echo $patient['DOB']; ?></p>
    <p class="Gender"><strong>Gender:</strong> <?php echo $patient['Gender']; ?></p>
    <p class="Address"><strong>Address:</strong> <?php echo $patient['Address']; ?></p>
    <p class="Contact_Number"><strong>Contact Number:</strong> <?php echo $patient['Contact_No']; ?></p>
</div>

                <?php } ?>
            <?php } else {
                echo "<p>No patients found.</p>";
            } ?>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
   <script>
    $(document).ready(function () {
        // Filter patients when Apply Filter button is clicked
        $("#filterCriteria, #filterValue").on("input", function () {
            var criteria = $("#filterCriteria").val();
            var filterValue = $("#filterValue").val().toLowerCase();

            $(".patient-card").each(function () {
                var patientData = $(this).find("p." + criteria).text().toLowerCase();
                if (criteria === "all" || patientData.includes(filterValue)) {
                    $(this).show();
                } else {
                    $(this).hide();
                }
            });
        });
    });
</script>


</body>
</html>
